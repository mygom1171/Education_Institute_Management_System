package dto;

public class VwsubcouromlecDTO {

	private String vcouname;
	private String vroomname;
	private String vlecname;
	private String vsubname;
	private String vcouseq;
	private String vsubseq;
	
	public String getVcouname() {
		return vcouname;
	}
	public void setVcouname(String vcouname) {
		this.vcouname = vcouname;
	}
	public String getVroomname() {
		return vroomname;
	}
	public void setVroomname(String vroomname) {
		this.vroomname = vroomname;
	}
	public String getVlecname() {
		return vlecname;
	}
	public void setVlecname(String vlecname) {
		this.vlecname = vlecname;
	}
	public String getVsubname() {
		return vsubname;
	}
	public void setVsubname(String vsubname) {
		this.vsubname = vsubname;
	}
	public String getVcouseq() {
		return vcouseq;
	}
	public void setVcouseq(String vcouseq) {
		this.vcouseq = vcouseq;
	}
	public String getVsubseq() {
		return vsubseq;
	}
	public void setVsubseq(String vsubseq) {
		this.vsubseq = vsubseq;
	}
	
	
	
}
