package dto;

public class VwstusinfoDTO {

	private String vstuname;
	private String vsturnum;
	private String vcouseq;
	private String vsinfoseq;
	
	public String getVstuname() {
		return vstuname;
	}
	public void setVstuname(String vstuname) {
		this.vstuname = vstuname;
	}
	public String getVsturnum() {
		return vsturnum;
	}
	public void setVsturnum(String vsturnum) {
		this.vsturnum = vsturnum;
	}
	public String getVcouseq() {
		return vcouseq;
	}
	public void setVcouseq(String vcouseq) {
		this.vcouseq = vcouseq;
	}
	public String getVsinfoseq() {
		return vsinfoseq;
	}
	public void setVsinfoseq(String vsinfoseq) {
		this.vsinfoseq = vsinfoseq;
	}
	
	
}
