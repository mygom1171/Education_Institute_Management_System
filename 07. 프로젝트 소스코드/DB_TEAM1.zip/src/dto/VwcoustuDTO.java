package dto;

public class VwcoustuDTO {

	private String vname;
	private String vseq;
	
	public String getVname() {
		return vname;
	}
	public void setVname(String vname) {
		this.vname = vname;
	}
	public String getVseq() {
		return vseq;
	}
	public void setVseq(String vseq) {
		this.vseq = vseq;
	}
	
	
}
