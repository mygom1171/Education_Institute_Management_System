package dto;

public class VwcousubDTO {

	private String vsubseq;
	private String vsubname;
	private String vcouseq;
	
	public String getVsubseq() {
		return vsubseq;
	}
	public void setVsubseq(String vsubseq) {
		this.vsubseq = vsubseq;
	}
	public String getVsubname() {
		return vsubname;
	}
	public void setVsubname(String vsubname) {
		this.vsubname = vsubname;
	}
	public String getVcouseq() {
		return vcouseq;
	}
	public void setVcouseq(String vcouseq) {
		this.vcouseq = vcouseq;
	}
	
	
}
