package dto;

public class VwsubjectAttendanceDTO {

	private String vCourseSeq;
	private String vStudentSeq;
	private String vStudentName;
	private String vSubjectSeq;
	private String vSubjectName;
	private String vSubjectStart;
	private String vSubjectEnd;
	
//-----------------------------------------------------------------	
	
	public String getvCourseSeq() {
		return vCourseSeq;
	}
	public void setvCourseSeq(String vCourseSeq) {
		this.vCourseSeq = vCourseSeq;
	}
	public String getvStudentSeq() {
		return vStudentSeq;
	}
	public void setvStudentSeq(String vStudentSeq) {
		this.vStudentSeq = vStudentSeq;
	}
	public String getvStudentName() {
		return vStudentName;
	}
	public void setvStudentName(String vStudentName) {
		this.vStudentName = vStudentName;
	}
	public String getvSubjectSeq() {
		return vSubjectSeq;
	}
	public void setvSubjectSeq(String vSubjectSeq) {
		this.vSubjectSeq = vSubjectSeq;
	}
	public String getvSubjectName() {
		return vSubjectName;
	}
	public void setvSubjectName(String vSubjectName) {
		this.vSubjectName = vSubjectName;
	}
	public String getvSubjectStart() {
		return vSubjectStart;
	}
	public void setvSubjectStart(String vSubjectStart) {
		this.vSubjectStart = vSubjectStart;
	}
	public String getvSubjectEnd() {
		return vSubjectEnd;
	}
	public void setvSubjectEnd(String vSubjectEnd) {
		this.vSubjectEnd = vSubjectEnd;
	}
	
}
