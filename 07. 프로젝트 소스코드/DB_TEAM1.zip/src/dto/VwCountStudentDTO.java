package dto;

public class VwCountStudentDTO {
	
	private String vcourseSeq;
	private String vcount;
	private String vlecturerseq;
	private String vcourseStartDate;
	private String vcourseEndDate;
	
	public String getVcourseSeq() {
		return vcourseSeq;
	}
	public void setVcourseSeq(String vcourseSeq) {
		this.vcourseSeq = vcourseSeq;
	}
	public String getVcount() {
		return vcount;
	}
	public void setVcount(String vcount) {
		this.vcount = vcount;
	}
	public String getVlecturerseq() {
		return vlecturerseq;
	}
	public void setVlecturerseq(String vlecturerseq) {
		this.vlecturerseq = vlecturerseq;
	}
	public String getVcourseStartDate() {
		return vcourseStartDate;
	}
	public void setVcourseStartDate(String vcourseStartDate) {
		this.vcourseStartDate = vcourseStartDate;
	}
	public String getVcourseEndDate() {
		return vcourseEndDate;
	}
	public void setVcourseEndDate(String vcourseEndDate) {
		this.vcourseEndDate = vcourseEndDate;
	}
	
	
	
	
}
