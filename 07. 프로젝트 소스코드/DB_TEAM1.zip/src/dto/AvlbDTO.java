package dto;

public class AvlbDTO {

	private String seq;
	private String lecturerSeq;
	private String subjectTypeSeq;
	
	
	
	
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getLecturerSeq() {
		return lecturerSeq;
	}
	public void setLecturerSeq(String lecturerSeq) {
		this.lecturerSeq = lecturerSeq;
	}
	public String getSubjectTypeSeq() {
		return subjectTypeSeq;
	}
	public void setSubjectTypeSeq(String subjectTypeSeq) {
		this.subjectTypeSeq = subjectTypeSeq;
	}
	
	
	
	
	
}
