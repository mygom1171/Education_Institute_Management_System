package dto;

public class VwattendancefinalDTO {

	private String studentseq;
	private String regdate;
	private String goout1;
	private String goout2;
	private String goout3;
	private String late1;
	private String late2;
	private String late3;
	private String late4;
	private String early1;
	private String early2;
	private String early3;
	private String early4;
	private String state;
	
	public String getStudentseq() {
		return studentseq;
	}
	public void setStudentseq(String studentseq) {
		this.studentseq = studentseq;
	}
	public String getRegdate() {
		return regdate;
	}
	public void setRegdate(String regdate) {
		this.regdate = regdate;
	}
	public String getGoout1() {
		return goout1;
	}
	public void setGoout1(String goout1) {
		this.goout1 = goout1;
	}
	public String getGoout2() {
		return goout2;
	}
	public void setGoout2(String goout2) {
		this.goout2 = goout2;
	}
	public String getGoout3() {
		return goout3;
	}
	public void setGoout3(String goout3) {
		this.goout3 = goout3;
	}
	public String getLate1() {
		return late1;
	}
	public void setLate1(String late1) {
		this.late1 = late1;
	}
	public String getLate2() {
		return late2;
	}
	public void setLate2(String late2) {
		this.late2 = late2;
	}
	public String getLate3() {
		return late3;
	}
	public void setLate3(String late3) {
		this.late3 = late3;
	}
	public String getLate4() {
		return late4;
	}
	public void setLate4(String late4) {
		this.late4 = late4;
	}
	public String getEarly1() {
		return early1;
	}
	public void setEarly1(String early1) {
		this.early1 = early1;
	}
	public String getEarly2() {
		return early2;
	}
	public void setEarly2(String early2) {
		this.early2 = early2;
	}
	public String getEarly3() {
		return early3;
	}
	public void setEarly3(String early3) {
		this.early3 = early3;
	}
	public String getEarly4() {
		return early4;
	}
	public void setEarly4(String early4) {
		this.early4 = early4;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
	
	
}
