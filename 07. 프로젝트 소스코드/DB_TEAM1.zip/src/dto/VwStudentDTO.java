package dto;

public class VwStudentDTO {
	
	private String vstudentSeq;
	private String vstudentName;
	private String vphoneNum;
	private String vregistrationtime;
	private String vstudentstatus;
	private String vcourseStartDate;
	private String vcourseEndDate;
	private String vcourseSeq;
	
	
	public String getVstudentSeq() {
		return vstudentSeq;
	}
	public void setVstudentSeq(String vstudentSeq) {
		this.vstudentSeq = vstudentSeq;
	}
	public String getVstudentName() {
		return vstudentName;
	}
	public void setVstudentName(String vstudentName) {
		this.vstudentName = vstudentName;
	}
	public String getVphoneNum() {
		return vphoneNum;
	}
	public void setVphoneNum(String vphoneNum) {
		this.vphoneNum = vphoneNum;
	}
	public String getVregistrationtime() {
		return vregistrationtime;
	}
	public void setVregistrationtime(String vregistrationtime) {
		this.vregistrationtime = vregistrationtime;
	}
	public String getVstudentstatus() {
		return vstudentstatus;
	}
	public void setVstudentstatus(String vstudentstatus) {
		this.vstudentstatus = vstudentstatus;
	}
	public String getVcourseStartDate() {
		return vcourseStartDate;
	}
	public void setVcourseStartDate(String vcourseStartDate) {
		this.vcourseStartDate = vcourseStartDate;
	}
	public String getVcourseEndDate() {
		return vcourseEndDate;
	}
	public void setVcourseEndDate(String vcourseEndDate) {
		this.vcourseEndDate = vcourseEndDate;
	}
	public String getVcourseSeq() {
		return vcourseSeq;
	}
	public void setVcourseSeq(String vcourseSeq) {
		this.vcourseSeq = vcourseSeq;
	}
	
	
}
