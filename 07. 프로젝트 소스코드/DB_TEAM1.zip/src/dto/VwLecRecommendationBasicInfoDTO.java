package dto;

public class VwLecRecommendationBasicInfoDTO {

	
	private String vcourseNameSeq;
	private String vname;
	private String vstartdate;
	private String venddate;
	
	
	public String getVcourseNameSeq() {
		return vcourseNameSeq;
	}
	public void setVcourseNameSeq(String vcourseNameSeq) {
		this.vcourseNameSeq = vcourseNameSeq;
	}
	public String getVname() {
		return vname;
	}
	public void setVname(String vname) {
		this.vname = vname;
	}
	public String getVstartdate() {
		return vstartdate;
	}
	public void setVstartdate(String vstartdate) {
		this.vstartdate = vstartdate;
	}
	public String getVenddate() {
		return venddate;
	}
	public void setVenddate(String venddate) {
		this.venddate = venddate;
	}
	
	
}
