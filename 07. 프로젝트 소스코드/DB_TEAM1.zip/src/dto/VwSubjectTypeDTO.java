package dto;

public class VwSubjectTypeDTO {
	
	 private String vAvlbSeq;
	 private String vTypeName;
	 private String vTypeSeq;
	 private String vLecturerSeq;
	
	 
	 public String getvAvlbSeq() {
		return vAvlbSeq;
	}
	public void setvAvlbSeq(String vAvlbSeq) {
		this.vAvlbSeq = vAvlbSeq;
	}
	public String getvTypeName() {
		return vTypeName;
	}
	public void setvTypeName(String vTypeName) {
		this.vTypeName = vTypeName;
	}
	public String getvTypeSeq() {
		return vTypeSeq;
	}
	public void setvTypeSeq(String vTypeSeq) {
		this.vTypeSeq = vTypeSeq;
	}
	public String getvLecturerSeq() {
		return vLecturerSeq;
	}
	public void setvLecturerSeq(String vLecturerSeq) {
		this.vLecturerSeq = vLecturerSeq;
	}
	 
	 
}
