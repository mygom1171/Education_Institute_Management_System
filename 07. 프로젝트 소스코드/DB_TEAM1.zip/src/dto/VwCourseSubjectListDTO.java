package dto;

public class VwCourseSubjectListDTO {
	
	private String vCourseSeq;
	private String vSubjectSeq;
	private String vSubjectName;
	private String vSubjectStart;
	private String vSubjectEnd;
	private String vTextbookName;
	private String vPublisherName;
	private String vLecturerName;
	
//----------------------------------------------------------	
	
	public String getvCourseSeq() {
		return vCourseSeq;
	}
	public void setvCourseSeq(String vCourseSeq) {
		this.vCourseSeq = vCourseSeq;
	}
	
	public String getvSubjectSeq() {
		return vSubjectSeq;
	}
	public void setvSubjectSeq(String vSubjectSeq) {
		this.vSubjectSeq = vSubjectSeq;
	}
	
	public String getvSubjectName() {
		return vSubjectName;
	}
	public void setvSubjectName(String vSubjectName) {
		this.vSubjectName = vSubjectName;
	}
	
	public String getvSubjectStart() {
		return vSubjectStart;
	}
	public void setvSubjectStart(String vSubjectStart) {
		this.vSubjectStart = vSubjectStart;
	}
	
	public String getvSubjectEnd() {
		return vSubjectEnd;
	}
	public void setvSubjectEnd(String vSubjectEnd) {
		this.vSubjectEnd = vSubjectEnd;
	}
	
	public String getvTextbookName() {
		return vTextbookName;
	}
	public void setvTextbookName(String vTextbookName) {
		this.vTextbookName = vTextbookName;
	}
	
	public String getvPublisherName() {
		return vPublisherName;
	}
	public void setvPublisherName(String vPublisherName) {
		this.vPublisherName = vPublisherName;
	}
	
	public String getvLecturerName() {
		return vLecturerName;
	}
	public void setvLecturerName(String vLecturerName) {
		this.vLecturerName = vLecturerName;
	}
	
}
