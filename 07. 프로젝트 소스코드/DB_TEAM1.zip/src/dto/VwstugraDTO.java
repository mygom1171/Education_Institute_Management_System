package dto;

public class VwstugraDTO {

	private String vstuname;
	private String vstupnum;
	private String vstustatus;
	private String vstuseq;
	private String vsubseq;
	private String vstustadate;
	private String vgraseq;
	
	public String getVstuname() {
		return vstuname;
	}
	public void setVstuname(String vstuname) {
		this.vstuname = vstuname;
	}
	public String getVstupnum() {
		return vstupnum;
	}
	public void setVstupnum(String vstupnum) {
		this.vstupnum = vstupnum;
	}
	public String getVstustatus() {
		return vstustatus;
	}
	public void setVstustatus(String vstustatus) {
		this.vstustatus = vstustatus;
	}
	public String getVstuseq() {
		return vstuseq;
	}
	public void setVstuseq(String vstuseq) {
		this.vstuseq = vstuseq;
	}
	
	public String getVstustadate() {
		return vstustadate;
	}
	public void setVstustadate(String vstustadate) {
		this.vstustadate = vstustadate;
	}
	public String getVgraseq() {
		return vgraseq;
	}
	public void setVgraseq(String vgraseq) {
		this.vgraseq = vgraseq;
	}
	public String getVsubseq() {
		return vsubseq;
	}
	public void setVsubseq(String vsubseq) {
		this.vsubseq = vsubseq;
	}
	
	
}
