package dto;

public class VwsinfoDTO {

	
	private String vstuname; 
	private String vstupnum; 
	private String vstustatus; 
	private String vstuseq;
	private String vgsubseq;
	private String vstatusdate;
	
	public String getVstuname() {
		return vstuname;
	}
	public void setVstuname(String vstuname) {
		this.vstuname = vstuname;
	}
	public String getVstupnum() {
		return vstupnum;
	}
	public void setVstupnum(String vstupnum) {
		this.vstupnum = vstupnum;
	}
	public String getVstustatus() {
		return vstustatus;
	}
	public void setVstustatus(String vstustatus) {
		this.vstustatus = vstustatus;
	}
	public String getVstuseq() {
		return vstuseq;
	}
	public void setVstuseq(String vstuseq) {
		this.vstuseq = vstuseq;
	}
		public String getVgsubseq() {
		return vgsubseq;
	}
	public void setVgsubseq(String vgsubseq) {
		this.vgsubseq = vgsubseq;
	}
	public String getVstatusdate() {
		return vstatusdate;
	}
	public void setVstatusdate(String vstatusdate) {
		this.vstatusdate = vstatusdate;
	} 
	
	
	
}
