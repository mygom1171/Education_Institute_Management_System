package dto;

public class VwcousubstubookDTO {

	private String vcouname;
	private String vcoustart;
	private String vcouend;
	private String vroomname;
	private String vsubname;
	private String vsubstart;
	private String vsubend;
	private String vbookname;
	private String vsubatt;
	private String vsubwrit;
	private String vsubprac;
	private String vcouseq;
	private String vsubseq;
	
	public String getVcouname() {
		return vcouname;
	}
	public void setVcouname(String vcouname) {
		this.vcouname = vcouname;
	}
	public String getVcoustart() {
		return vcoustart;
	}
	public void setVcoustart(String vcoustart) {
		this.vcoustart = vcoustart;
	}
	public String getVcouend() {
		return vcouend;
	}
	public void setVcouend(String vcouend) {
		this.vcouend = vcouend;
	}
	public String getVroomname() {
		return vroomname;
	}
	public void setVroomname(String vroomname) {
		this.vroomname = vroomname;
	}
	public String getVsubname() {
		return vsubname;
	}
	public void setVsubname(String vsubname) {
		this.vsubname = vsubname;
	}
	public String getVsubstart() {
		return vsubstart;
	}
	public void setVsubstart(String vsubstart) {
		this.vsubstart = vsubstart;
	}
	public String getVsubend() {
		return vsubend;
	}
	public void setVsubend(String vsubend) {
		this.vsubend = vsubend;
	}
	public String getVbookname() {
		return vbookname;
	}
	public void setVbookname(String vbookname) {
		this.vbookname = vbookname;
	}
	public String getVsubatt() {
		return vsubatt;
	}
	public void setVsubatt(String vsubatt) {
		this.vsubatt = vsubatt;
	}
	public String getVsubwrit() {
		return vsubwrit;
	}
	public void setVsubwrit(String vsubwrit) {
		this.vsubwrit = vsubwrit;
	}
	public String getVsubprac() {
		return vsubprac;
	}
	public void setVsubprac(String vsubprac) {
		this.vsubprac = vsubprac;
	}
	public String getVcouseq() {
		return vcouseq;
	}
	public void setVcouseq(String vcouseq) {
		this.vcouseq = vcouseq;
	}
	public String getVsubseq() {
		return vsubseq;
	}
	public void setVsubseq(String vsubseq) {
		this.vsubseq = vsubseq;
	}
	
}
