package dto;

public class VwCourseDTO {
	
	private String vcourseSeq;
	private String vcourseName;
	private String vcourseStartDate;
	private String vcourseEndDate;
	private String vclassroom;
	private String vlecturerSeq;
	
	public String getVcourseSeq() {
		return vcourseSeq;
	}
	public void setVcourseSeq(String vcourseSeq) {
		this.vcourseSeq = vcourseSeq;
	}
	public String getVcourseName() {
		return vcourseName;
	}
	public void setVcourseName(String vcourseName) {
		this.vcourseName = vcourseName;
	}
	public String getVcourseStartDate() {
		return vcourseStartDate;
	}
	public void setVcourseStartDate(String vcourseStartDate) {
		this.vcourseStartDate = vcourseStartDate;
	}
	public String getVcourseEndDate() {
		return vcourseEndDate;
	}
	public void setVcourseEndDate(String vcourseEndDate) {
		this.vcourseEndDate = vcourseEndDate;
	}
	public String getVclassroom() {
		return vclassroom;
	}
	public void setVclassroom(String vclassroom) {
		this.vclassroom = vclassroom;
	}
	public String getVlecturerSeq() {
		return vlecturerSeq;
	}
	public void setVlecturerSeq(String vlecturerSeq) {
		this.vlecturerSeq = vlecturerSeq;
	}
	
	
	
}
