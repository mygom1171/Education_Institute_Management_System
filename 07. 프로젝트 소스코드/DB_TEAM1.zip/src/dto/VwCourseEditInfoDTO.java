package dto;

public class VwCourseEditInfoDTO {

	private String vCourseNum;
	private String vCourseName;
	private String vCourseStart;
	private String vCourseEnd;
	private String vCourseClassroom;
	private String vCourseLecturerSeq;
	private String vCourseLecturer;
	
//--------------------------------------------------------------------------	
	
	public String getvCourseNum() {
		return vCourseNum;
	}
	public void setvCourseNum(String vCourseNum) {
		this.vCourseNum = vCourseNum;
	}
	
	
	public String getvCourseName() {
		return vCourseName;
	}
	public void setvCourseName(String vCourseName) {
		this.vCourseName = vCourseName;
	}
	
	
	public String getvCourseStart() {
		return vCourseStart;
	}
	public void setvCourseStart(String vCourseStart) {
		this.vCourseStart = vCourseStart;
	}
	
	
	public String getvCourseEnd() {
		return vCourseEnd;
	}
	public void setvCourseEnd(String vCourseEnd) {
		this.vCourseEnd = vCourseEnd;
	}
	
	
	public String getvCourseClassroom() {
		return vCourseClassroom;
	}
	public void setvCourseClassroom(String vCourseClassroom) {
		this.vCourseClassroom = vCourseClassroom;
	}
	
	
	public String getvCourseLecturerSeq() {
		return vCourseLecturerSeq;
	}
	public void setvCourseLecturerSeq(String vCourseLecturerSeq) {
		this.vCourseLecturerSeq = vCourseLecturerSeq;
	}
	
	
	public String getvCourseLecturer() {
		return vCourseLecturer;
	}
	public void setvCourseLecturer(String vCourseLecturer) {
		this.vCourseLecturer = vCourseLecturer;
	}
	
}
