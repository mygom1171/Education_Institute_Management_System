package dto;

public class VwsubgraquizDTO {

	
	private String vsubnanme; 
	private String vsubstart;
	private String vsubend; 
	private String vtextname; 
	private String vlecturername; 
	private String vsubpracpercent; 
	private String vsubwrittenpercent; 
	private String vgrawritten; 
	private String vgrapractical; 
	private String vquizdate; 
	private String vstuinseq; 
	private String vsubseq;
	
	
	
	public String getVsubnanme() {
		return vsubnanme;
	}
	public void setVsubnanme(String vsubnanme) {
		this.vsubnanme = vsubnanme;
	}
	public String getVsubstart() {
		return vsubstart;
	}
	public void setVsubstart(String vsubstart) {
		this.vsubstart = vsubstart;
	}
	public String getVsubend() {
		return vsubend;
	}
	public void setVsubend(String vsubend) {
		this.vsubend = vsubend;
	}
	public String getVtextname() {
		return vtextname;
	}
	public void setVtextname(String vtextname) {
		this.vtextname = vtextname;
	}
	public String getVlecturername() {
		return vlecturername;
	}
	public void setVlecturername(String vlecturername) {
		this.vlecturername = vlecturername;
	}
	public String getVsubpracpercent() {
		return vsubpracpercent;
	}
	public void setVsubpracpercent(String vsubpracpercent) {
		this.vsubpracpercent = vsubpracpercent;
	}
	public String getVsubwrittenpercent() {
		return vsubwrittenpercent;
	}
	public void setVsubwrittenpercent(String vsubwrittenpercent) {
		this.vsubwrittenpercent = vsubwrittenpercent;
	}
	public String getVgrawritten() {
		return vgrawritten;
	}
	public void setVgrawritten(String vgrawritten) {
		this.vgrawritten = vgrawritten;
	}
	public String getVgrapractical() {
		return vgrapractical;
	}
	public void setVgrapractical(String vgrapractical) {
		this.vgrapractical = vgrapractical;
	}
	public String getVquizdate() {
		return vquizdate;
	}
	public void setVquizdate(String vquizdate) {
		this.vquizdate = vquizdate;
	}
	public String getVstuinseq() {
		return vstuinseq;
	}
	public void setVstuinseq(String vstuinseq) {
		this.vstuinseq = vstuinseq;
	}
	public String getVsubseq() {
		return vsubseq;
	}
	public void setVsubseq(String vsubseq) {
		this.vsubseq = vsubseq;
	} 

	
	
}
