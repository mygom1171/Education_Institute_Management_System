package dto;

public class VwsubcouroomlecDTO {

	private String vcouname;
	private String vroomname;
	private String vlecname;
	private String vsubname;
	private String vcouseq;
	private String vsubseq;
	private String vsubstart;
	private String vsubend;
	private String vtextname;
	
	public String getVcouname() {
		return vcouname;
	}
	public void setVcouname(String vcouname) {
		this.vcouname = vcouname;
	}
	public String getVroomname() {
		return vroomname;
	}
	public void setVroomname(String vroomname) {
		this.vroomname = vroomname;
	}
	public String getVlecname() {
		return vlecname;
	}
	public void setVlecname(String vlecname) {
		this.vlecname = vlecname;
	}
	public String getVsubname() {
		return vsubname;
	}
	public void setVsubname(String vsubname) {
		this.vsubname = vsubname;
	}
	public String getVcouseq() {
		return vcouseq;
	}
	public void setVcouseq(String vcouseq) {
		this.vcouseq = vcouseq;
	}
	public String getVsubseq() {
		return vsubseq;
	}
	public void setVsubseq(String vsubseq) {
		this.vsubseq = vsubseq;
	}
	public String getVsubstart() {
		return vsubstart;
	}
	public void setVsubstart(String vsubstart) {
		this.vsubstart = vsubstart;
	}
	public String getVsubend() {
		return vsubend;
	}
	public void setVsubend(String vsubend) {
		this.vsubend = vsubend;
	}
	public String getVtextname() {
		return vtextname;
	}
	public void setVtextname(String vtextname) {
		this.vtextname = vtextname;
	}
	
	
	
}
