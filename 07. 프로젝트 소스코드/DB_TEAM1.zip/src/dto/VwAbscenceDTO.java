package dto;

public class VwAbscenceDTO {
	
	private String regdate;
	private String rstudentSeq;
	private String rabscence;
	
	public String getRegdate() {
		return regdate;
	}
	public void setRegdate(String regdate) {
		this.regdate = regdate;
	}
	public String getRstudentSeq() {
		return rstudentSeq;
	}
	public void setRstudentSeq(String rstudentSeq) {
		this.rstudentSeq = rstudentSeq;
	}
	public String getRabscence() {
		return rabscence;
	}
	public void setRabscence(String rabscence) {
		this.rabscence = rabscence;
	}

	
	
	
}
