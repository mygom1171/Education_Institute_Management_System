package dto;

public class VwGradeListDTO {

	private String vSubjectSeq;
	private String vSubjectName;
	private String vSubjectStartDate;
	private String vSubjectEndDate;
	private String vTextBook;
	private String vLecturer;
	private String vWrittenpercent;
	private String vPracticalPercent;
	private String vAttendancepercent;
	private String vPracticalTotal;
	private String vWrittenTotal;
	private String vAttendanceTotal;
	
	
	
	
	public String getvSubjectSeq() {
		return vSubjectSeq;
	}
	public void setvSubjectSeq(String vSubjectSeq) {
		this.vSubjectSeq = vSubjectSeq;
	}
	public String getvPracticalTotal() {
		return vPracticalTotal;
	}
	public void setvPracticalTotal(String vPracticalTotal) {
		this.vPracticalTotal = vPracticalTotal;
	}
	






	public String getvWrittenTotal() {
		return vWrittenTotal;
	}
	public void setvWrittenTotal(String vWrittenTotal) {
		this.vWrittenTotal = vWrittenTotal;
	}
	public String getvAttendanceTotal() {
		return vAttendanceTotal;
	}
	public void setvAttendanceTotal(String vAttendanceTotal) {
		this.vAttendanceTotal = vAttendanceTotal;
	}







	private String vQuizDate;
	

	public String getvSubjectName() {
		return vSubjectName;
	}
	public void setvSubjectName(String vSubjectName) {
		this.vSubjectName = vSubjectName;
	}
	public String getvSubjectStartDate() {
		return vSubjectStartDate;
	}
	public void setvSubjectStartDate(String vSubjectStartDate) {
		this.vSubjectStartDate = vSubjectStartDate;
	}
	public String getvSubjectEndDate() {
		return vSubjectEndDate;
	}
	public void setvSubjectEndDate(String vSubjectEndDate) {
		this.vSubjectEndDate = vSubjectEndDate;
	}
	public String getvTextBook() {
		return vTextBook;
	}
	public void setvTextBook(String vTextBook) {
		this.vTextBook = vTextBook;
	}
	public String getvLecturer() {
		return vLecturer;
	}
	public void setvLecturer(String vLecturer) {
		this.vLecturer = vLecturer;
	}
	public String getvWrittenpercent() {
		return vWrittenpercent;
	}
	public void setvWrittenpercent(String vWrittenpercent) {
		this.vWrittenpercent = vWrittenpercent;
	}
	public String getvPracticalPercent() {
		return vPracticalPercent;
	}
	public void setvPracticalPercent(String vPracticalPercent) {
		this.vPracticalPercent = vPracticalPercent;
	}
	public String getvAttendancepercent() {
		return vAttendancepercent;
	}
	public void setvAttendancepercent(String vAttendancepercent) {
		this.vAttendancepercent = vAttendancepercent;
	}
	public String getvQuizDate() {
		return vQuizDate;
	}
	public void setvQuizDate(String vQuizDate) {
		this.vQuizDate = vQuizDate;
	}
	
	
	
}
