package dto;

public class VwSubjectPercentQuizDTO {
	
	private String vCourseNum;
	private String vSubjectNum;
	private String vSubjectName;
	private String vWrittenPercent;
	private String vPracticalPercent;
	private String vAttendancePercent;
	private String vQuizNum;
	private String vQuizDate;
	private String vQuizContnts;
	private String vQuizAnswer;
	private String vQuizState;
	
//--------------------------------------------------------------
	
	public String getvCourseNum() {
		return vCourseNum;
	}
	public void setvCourseNum(String vCourseNum) {
		this.vCourseNum = vCourseNum;
	}
	public String getvSubjectNum() {
		return vSubjectNum;
	}
	public void setvSubjectNum(String vSubjectNum) {
		this.vSubjectNum = vSubjectNum;
	}
	public String getvSubjectName() {
		return vSubjectName;
	}
	public void setvSubjectName(String vSubjectName) {
		this.vSubjectName = vSubjectName;
	}
	public String getvWrittenPercent() {
		return vWrittenPercent;
	}
	public void setvWrittenPercent(String vWrittenPercent) {
		this.vWrittenPercent = vWrittenPercent;
	}
	public String getvPracticalPercent() {
		return vPracticalPercent;
	}
	public void setvPracticalPercent(String vPracticalPercent) {
		this.vPracticalPercent = vPracticalPercent;
	}
	public String getvAttendancePercent() {
		return vAttendancePercent;
	}
	public void setvAttendancePercent(String vAttendancePercent) {
		this.vAttendancePercent = vAttendancePercent;
	}
	public String getvQuizNum() {
		return vQuizNum;
	}
	public void setvQuizNum(String vQuizNum) {
		this.vQuizNum = vQuizNum;
	}
	public String getvQuizDate() {
		return vQuizDate;
	}
	public void setvQuizDate(String vQuizDate) {
		this.vQuizDate = vQuizDate;
	}	
	public String getvQuizContnts() {
		return vQuizContnts;
	}
	public void setvQuizContnts(String vQuizContnts) {
		this.vQuizContnts = vQuizContnts;
	}
	public String getvQuizAnswer() {
		return vQuizAnswer;
	}
	public void setvQuizAnswer(String vQuizAnswer) {
		this.vQuizAnswer = vQuizAnswer;
	}
	public String getvQuizState() {
		return vQuizState;
	}
	public void setvQuizState(String vQuizState) {
		this.vQuizState = vQuizState;
	}
	
}
