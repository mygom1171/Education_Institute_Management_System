package dto;

public class StudentDTO {

	private String seq;
	private String studentInfoSeq;
	private String courseSeq;
	private String registrationTime;
	private String status;
	
	
	
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getStudentInfoSeq() {
		return studentInfoSeq;
	}
	public void setStudentInfoSeq(String studentInfoSeq) {
		this.studentInfoSeq = studentInfoSeq;
	}
	public String getCourseSeq() {
		return courseSeq;
	}
	public void setCourseSeq(String courseSeq) {
		this.courseSeq = courseSeq;
	}
	public String getRegistrationTime() {
		return registrationTime;
	}
	public void setRegistrationTime(String registrationTime) {
		this.registrationTime = registrationTime;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
}
