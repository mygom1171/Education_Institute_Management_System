package dto;

public class VwSubjectNameDTO {

	private String vLecturerName;
	private String vSeq;
	private String vAvailableSubject;
	
//-----------------------------------------------------------------	
	
	public String getvLecturerName() {
		return vLecturerName;
	}
	public void setvLecturerName(String vLecturerName) {
		this.vLecturerName = vLecturerName;
	}
	public String getvSeq() {
		return vSeq;
	}
	public void setvSeq(String vSeq) {
		this.vSeq = vSeq;
	}
	public String getvAvailableSubject() {
		return vAvailableSubject;
	}
	public void setvAvailableSubject(String vAvailableSubject) {
		this.vAvailableSubject = vAvailableSubject;
	}
	
}
