package dto;

public class AttendanceDTO {

	private String seq;
	private String studentSeq;
	private String goTo;
	private String comeBack;
	
//--------------------------------------------------------------
	
	public String getSeq() {
		return seq;
	}
	public void setSeq(String seq) {
		this.seq = seq;
	}
	public String getStudentSeq() {
		return studentSeq;
	}
	public void setStudentSeq(String studentSeq) {
		this.studentSeq = studentSeq;
	}
	public String getGoTo() {
		return goTo;
	}
	public void setGoTo(String goTo) {
		this.goTo = goTo;
	}
	public String getComeBack() {
		return comeBack;
	}
	public void setComeBack(String comeBack) {
		this.comeBack = comeBack;
	}
	
}
