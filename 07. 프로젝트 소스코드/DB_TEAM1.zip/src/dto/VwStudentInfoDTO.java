package dto;

public class VwStudentInfoDTO {

	private String vStudentName;
	private String vCourseName;
	private String vCourseStartDate;
	private String vCourseEndDate;
	private String vClassRoom;
	

	public String getvStudentName() {
		return vStudentName;
	}
	public void setvStudentName(String vStudentName) {
		this.vStudentName = vStudentName;
	}
	public String getvCourseName() {
		return vCourseName;
	}
	public void setvCourseName(String vCourseName) {
		this.vCourseName = vCourseName;
	}
	public String getvCourseStartDate() {
		return vCourseStartDate;
	}
	public void setvCourseStartDate(String vCourseStartDate) {
		this.vCourseStartDate = vCourseStartDate;
	}
	public String getvCourseEndDate() {
		return vCourseEndDate;
	}
	public void setvCourseEndDate(String vCourseEndDate) {
		this.vCourseEndDate = vCourseEndDate;
	}
	public String getvClassRoom() {
		return vClassRoom;
	}
	public void setvClassRoom(String vClassRoom) {
		this.vClassRoom = vClassRoom;
	}
	
}
