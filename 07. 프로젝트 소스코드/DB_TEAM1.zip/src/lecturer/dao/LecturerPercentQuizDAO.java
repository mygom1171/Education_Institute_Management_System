package lecturer.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import dto.QuizDTO;
import dto.SubjectDTO;
import dto.VwCourseEditInfoDTO;
import dto.VwCourseSubjectListDTO;
import dto.VwSubjectPercentQuizDTO;
import util.DBUtil;

public class LecturerPercentQuizDAO {

	private Connection conn;
	private Statement stat;
	private PreparedStatement pstat;
	
//-----------------------------------------------------	

	public LecturerPercentQuizDAO() {
		
		try {
			DBUtil util = new DBUtil();
			this.conn = util.connect();
			this.stat = conn.createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("DAO생성자에서 오류");
		}
		
	}//method : LecturerPercentQuizDAO
	
//-----------------------------------------------------	

	public boolean isConnected() {
		
		try {
			return !this.conn.isClosed();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return false;
		
	}
	
//-----------------------------------------------------
	
	public void close() {
		
		try {
			this.conn.close();
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
	}//Method : close

	
	
//과정, 과목 목록
//=====================================================================================================================================
	
	//과정 목록
	public ArrayList<String> courseList(String lecturerSeq) {
		
		try {
			
			String sql = String.format("SELECT * FROM vwCourseEditInfo WHERE \"vCourseLecturerSeq\" = %s", lecturerSeq);
			ResultSet rs = stat.executeQuery(sql);
			
			ArrayList<VwCourseEditInfoDTO> courseEditList = new ArrayList<VwCourseEditInfoDTO>();
			
			while (rs.next()) {				
				VwCourseEditInfoDTO courseEditInfoDto = new VwCourseEditInfoDTO();
				
				courseEditInfoDto.setvCourseNum(rs.getString("vCourseNum"));
				courseEditInfoDto.setvCourseName(rs.getString("vCourseName"));
				courseEditInfoDto.setvCourseStart(rs.getString("vCourseStart"));
				courseEditInfoDto.setvCourseEnd(rs.getString("vCourseEnd"));
				courseEditInfoDto.setvCourseClassroom(rs.getString("vCourseClassroom"));
				courseEditInfoDto.setvCourseLecturer(rs.getString("vCourseLecturer"));
				
				courseEditList.add(courseEditInfoDto);					
			}
			
			ArrayList<String> tempList = new ArrayList<String>();
			
			for (VwCourseEditInfoDTO courseEditInfoDto : courseEditList) {
				tempList.add(
					"\t과정번호\t[" + courseEditInfoDto.getvCourseNum() + "]"
					+ "\n\t--------------------------------------------------------------------------"
					+ "\n\t과정명\t\t" + courseEditInfoDto.getvCourseName()
					+ "\n\t--------------------------------------------------------------------------"
					+ "\n\t과정기간\t" + courseEditInfoDto.getvCourseStart().substring(0, 10) + " ~ " 
											+ courseEditInfoDto.getvCourseEnd().substring(0, 10)
					+ "\n\t--------------------------------------------------------------------------"
					+ "\n\t강의실\t\t" + courseEditInfoDto.getvCourseClassroom()
					+ "\n\t--------------------------------------------------------------------------"
					+ "\n\t교사\t\t" + courseEditInfoDto.getvCourseLecturer()
					+ "\n\t==========================================================================");
			}
			
			return tempList;
			
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		
		return null;
		
	}//method : courseList
	
	
	//선택한 과정의 이름
	public String selectCourseListName(String vCourseNum) {
		
		try {
			
			String sql = String.format("SELECT * FROM vwCourseEditInfo WHERE \"vCourseNum\" = %s", vCourseNum);
			ResultSet rs = stat.executeQuery(sql);
			
			while (rs.next()) {
				String courseName = rs.getString("vCourseName");
				return courseName;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
		
	}//method : selectCourseListName

//--------------------------------------------------------------------------------------------------------------------------------
	
	//과목 목록
	public ArrayList<String> subjectList(String vCourseSeq) {
		
		try {
			
			String sql = String.format("SELECT * FROM vwCourseSubjectList WHERE \"vCourseSeq\" = %s "
											+ "AND \"vSubjectEnd\" < SYSDATE AND state = 1", vCourseSeq);
			ResultSet rs = stat.executeQuery(sql);
			
			ArrayList<VwCourseSubjectListDTO> courseSubjectList = new ArrayList<VwCourseSubjectListDTO>();
			
			while (rs.next()) {				
				VwCourseSubjectListDTO courseSubjectListDTO = new VwCourseSubjectListDTO();
				
				courseSubjectListDTO.setvSubjectSeq(rs.getString("vSubjectSeq"));
				courseSubjectListDTO.setvSubjectName(rs.getString("vSubjectName"));	
				courseSubjectListDTO.setvSubjectStart(rs.getString("vSubjectStart"));
				courseSubjectListDTO.setvSubjectEnd(rs.getString("vSubjectEnd"));
				
				courseSubjectList.add(courseSubjectListDTO);					
			}
			
			ArrayList<String> tempList = new ArrayList<String>();
			
			for (VwCourseSubjectListDTO courseSubjectListDTO : courseSubjectList) {
				tempList.add(
						"\n\t=========================================================================="
						+ "\n\t과목번호\t[" + courseSubjectListDTO.getvSubjectSeq() + "]"
						+ "\n\t--------------------------------------------------------------------------"
						+ "\n\t과목명\t\t" + courseSubjectListDTO.getvSubjectName()
						+ "\n\t--------------------------------------------------------------------------"
						+ "\n\t과목기간\t" + courseSubjectListDTO.getvSubjectStart().substring(0, 10) + " ~ "
												+ courseSubjectListDTO.getvSubjectEnd().substring(0, 10)
						+ "\n\t==========================================================================");
			}
			
			return tempList;
			
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		
		return null;
		
	}//method : subjectList

	
	//선택한 과목의 이름
	public String selectSubjectListName(String subjectSeq) {
		
		try {
			
			String sql = String.format("SELECT * FROM vwCourseSubjectList WHERE \"vSubjectSeq\" = %s", subjectSeq);
			ResultSet rs = stat.executeQuery(sql);
			
			while (rs.next()) {
				String subjectName = rs.getString("vSubjectName");
				return subjectName;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
		
	}//method : selectSubjectListName

	
	//선택한 과목의 배점정보, 시험정보
	public ArrayList<String> subjectPercentQuiz(String vCourseNum, String vSubjectNum) {
		
		try {
			
			String sql = String.format("SELECT DISTINCT vSubjectName, vWrittenPercent, vPracticalPercent, "
											+ "vAttendancePercent, vQuizDate FROM vwSubjectPercentQuiz "
												+ "WHERE vCourseNum = %s AND vsubjectnum = %s", vCourseNum,vSubjectNum);
			
			ResultSet rs = stat.executeQuery(sql);
			
			ArrayList<VwSubjectPercentQuizDTO> subjectPercentQuizList = new ArrayList<VwSubjectPercentQuizDTO>();
			
			while (rs.next()) {				
				VwSubjectPercentQuizDTO subjectPercentQuizDTO = new VwSubjectPercentQuizDTO();
				
				subjectPercentQuizDTO.setvSubjectName(rs.getString("vSubjectName"));
				subjectPercentQuizDTO.setvWrittenPercent(rs.getString("vWrittenPercent"));
				subjectPercentQuizDTO.setvPracticalPercent(rs.getString("vPracticalPercent"));
				subjectPercentQuizDTO.setvAttendancePercent(rs.getString("vAttendancePercent"));
				subjectPercentQuizDTO.setvQuizDate(rs.getString("vQuizDate"));
				
				subjectPercentQuizList.add(subjectPercentQuizDTO);					
			}
			
			ArrayList<String> tempList = new ArrayList<String>();
			
			for (VwSubjectPercentQuizDTO subjectPercentQuizDTO : subjectPercentQuizList) {
				
				String quizNull, writtenNull, practicalNull, attendanceNull;
				
				if(subjectPercentQuizDTO.getvWrittenPercent() == null) writtenNull = "X";
				else writtenNull = subjectPercentQuizDTO.getvWrittenPercent();
				
				if(subjectPercentQuizDTO.getvPracticalPercent() == null) practicalNull = "X";
				else practicalNull = subjectPercentQuizDTO.getvPracticalPercent();
				
				if(subjectPercentQuizDTO.getvAttendancePercent() == null) attendanceNull = "X";
				else attendanceNull = subjectPercentQuizDTO.getvAttendancePercent();
				
				if(subjectPercentQuizDTO.getvQuizDate() == null) quizNull = "시험날짜가 입력되지 않음";
				else quizNull = subjectPercentQuizDTO.getvQuizDate().substring(0, 10);
				
				tempList.add(
						"\t과목명\t\t" + subjectPercentQuizDTO.getvSubjectName()
						+ "\n\t--------------------------------------------------------------------------"
						+ "\n\t배점\t\t필기" + writtenNull + "\t실기" + practicalNull + "\t출결" + attendanceNull
						+ "\n\t--------------------------------------------------------------------------"
						+ "\n\t시험날짜\t" + quizNull
						+ "\n\t==========================================================================");
			}
			
			return tempList;
			
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		
		return null;
		
	}//method : subjectPercentQuiz

//=====================================================================================================================================
	
	
	
//배점 관리	
//=====================================================================================================================================
	
	//배점 입력
	public int percentAdd(SubjectDTO subjectDTO) {
		
		String sql = "UPDATE tblSubject SET writtenPercent = ?, practicalPercent = ?, attendancePercent = ? "
						+ "WHERE courseseq = ? AND seq = ?";

		try {
			
			pstat = conn.prepareStatement(sql);
			
			pstat.setString(1, subjectDTO.getWrittenPercent());
			pstat.setString(2, subjectDTO.getPracticalPercent());
			pstat.setString(3, subjectDTO.getAttendancePercent());
			pstat.setString(4, subjectDTO.getCourseSeq());
			pstat.setString(5, subjectDTO.getSeq());
			
			return pstat.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return 0;
		
	}//method : percentAdd

	
	//배점 수정
	public int percentEdit(SubjectDTO subjectDTO) {
		
		String sql = "UPDATE tblSubject SET writtenPercent = ?, practicalPercent = ?, attendancePercent = ? "
				+ "WHERE courseseq = ? AND seq = ?";

		try {
			
			pstat = conn.prepareStatement(sql);
			
			pstat.setString(1, subjectDTO.getWrittenPercent());
			pstat.setString(2, subjectDTO.getPracticalPercent());
			pstat.setString(3, subjectDTO.getAttendancePercent());
			pstat.setString(4, subjectDTO.getCourseSeq());
			pstat.setString(5, subjectDTO.getSeq());
			
			return pstat.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return 0;
		
	}//method : percentEdit

	
	
	//배점 삭제
	public int percentDelete(SubjectDTO subjectDTO) {

		String sql = "UPDATE tblSubject SET writtenPercent = NULL, practicalPercent = NULL, attendancePercent = NULL "
				+ "WHERE courseseq = ? AND seq = ?";

		try {
			
			pstat = conn.prepareStatement(sql);
			
			pstat.setString(1, subjectDTO.getWrittenPercent());
			pstat.setString(2, subjectDTO.getPracticalPercent());
			pstat.setString(3, subjectDTO.getAttendancePercent());
			pstat.setString(4, subjectDTO.getCourseSeq());
			pstat.setString(5, subjectDTO.getSeq());
			
			return pstat.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return 0;
		
	}//method : method : percentDelete
	
//=====================================================================================================================================

	
	
//시험 날짜 관리
//=====================================================================================================================================
	
	//시험 날짜 입력
	public int quizDateAdd(QuizDTO quizDTO) {
		
		String sql = "UPDATE tblQuiz SET quizDate = ? WHERE subjectSeq = ?";

		try {
			
			pstat = conn.prepareStatement(sql);
			
			pstat.setString(1, quizDTO.getQuizDate());
			pstat.setString(2, quizDTO.getSubjectSeq());
			
			return pstat.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return 0;
		
	}//method : quizDateAdd
	
	
	//시험 날짜 수정
	public int quizDateEdit(QuizDTO quizDTO) {
		
		String sql = "UPDATE tblQuiz SET quizDate = ? WHERE subjectSeq = ?";

		try {
			
			pstat = conn.prepareStatement(sql);
			
			pstat.setString(1, quizDTO.getQuizDate());
			pstat.setString(2, quizDTO.getSubjectSeq());
			
			return pstat.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return 0;
		
	}//method : quizDateEdit

	
	//시험 날짜 삭제
	public int quizDateDelete(QuizDTO quizDTO) {
		
		String sql = "UPDATE tblQuiz SET quizDate = NULL WHERE subjectSeq = ?";

		try {
			
			pstat = conn.prepareStatement(sql);
			
			pstat.setString(1, quizDTO.getQuizDate());
			pstat.setString(2, quizDTO.getSubjectSeq());
			
			return pstat.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return 0;
		
	}//method : quizDateDelete
	
//=====================================================================================================================================	
	
	
	
	
//시험 문제 관리	
//=====================================================================================================================================

	//시험 문제 추가
	public int quizQuestionAdd(QuizDTO quizDTO) {

		String sql = "INSERT INTO tblQuiz (seq, type, num, contents, answer, subseq, quizdate, state)" 
						+ "VALUES (quizSeq.NEXTVAL, \'필기\', ?, ?, ?, ?, DEFAULT, DEFAULT)";

		try {
			
			pstat = conn.prepareStatement(sql);
			
			pstat.setString(1, quizDTO.getNum());
			pstat.setString(2, quizDTO.getContents());
			pstat.setString(3, quizDTO.getAnswer());
			pstat.setString(4, quizDTO.getSubjectSeq());
			
			return pstat.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return 0;
		
	}//method : quizQuestionAdd

	
	
	//시험 문제 내용 수정
	public int quizQuestionContentEdit(QuizDTO quizDTO) {
		
		String sql = "UPDATE tblQuiz SET contents = ? WHERE NUM = ? AND subjectseq = ?";

		try {
			
			pstat = conn.prepareStatement(sql);
			
			pstat.setString(1, quizDTO.getContents());
			pstat.setString(2, quizDTO.getNum());
			pstat.setString(3, quizDTO.getSubjectSeq());
			
			return pstat.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return 0;
		
	}//method : quizQuestionContentEdit
	
	
	
	//시험 문제 정답 수정
	public int quizQuestionAnswerEdit(QuizDTO quizDTO) {

		String sql = "UPDATE tblQuiz SET answer = ? WHERE NUM = ? AND subjectseq = ?";

		try {
			
			pstat = conn.prepareStatement(sql);
			
			pstat.setString(1, quizDTO.getAnswer());
			pstat.setString(2, quizDTO.getNum());
			pstat.setString(3, quizDTO.getSubjectSeq());
			
			return pstat.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return 0;
		
	}//method : quizQuestionAnswerEdit
	
	
	
	//시험 문제 삭제
	public ArrayList<String> quizQuestionDelete(String vCourseNum, String vSubjectNum) {
		
		try {
			
			String sql = String.format("SELECT DISTINCT vQuizNum, vQuizContnts, vQuizAnswer "
											+ "FROM vwSubjectPercentQuiz "
												+ "WHERE vCourseNum = %s AND vsubjectnum = %s AND vQuizState = 1 "
													+ "ORDER BY vQuizNum"
														, vCourseNum,vSubjectNum);
			
			ResultSet rs = stat.executeQuery(sql);
			
			ArrayList<VwSubjectPercentQuizDTO> quizQuestionDeleteList = new ArrayList<VwSubjectPercentQuizDTO>();
			
			while (rs.next()) {				
				VwSubjectPercentQuizDTO subjectPercentQuizDTO = new VwSubjectPercentQuizDTO();
				
				subjectPercentQuizDTO.setvQuizNum(rs.getString("vQuizNum"));
				subjectPercentQuizDTO.setvQuizContnts(rs.getString("vQuizContnts"));
				subjectPercentQuizDTO.setvQuizAnswer(rs.getString("vQuizAnswer"));
				
				quizQuestionDeleteList.add(subjectPercentQuizDTO);					
			}
			
			ArrayList<String> tempList = new ArrayList<String>();
			
			for (VwSubjectPercentQuizDTO subjectPercentQuizDTO : quizQuestionDeleteList) {
				
				String quizContents = "";
				
				if (subjectPercentQuizDTO.getvQuizContnts().length() > 40) {
					
					quizContents += subjectPercentQuizDTO.getvQuizContnts().substring(0, 40);
					quizContents += "\n\t" + subjectPercentQuizDTO.getvQuizContnts().substring(40);
					
				} else {
					quizContents = subjectPercentQuizDTO.getvQuizContnts();
				}

				tempList.add(
						"\t[문제 " + subjectPercentQuizDTO.getvQuizNum() + "]"
						+ "\n\n\t" + quizContents
						+ "\n\n\t정답 : " + subjectPercentQuizDTO.getvQuizAnswer());
			}
			
			return tempList;
			
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		
		return null;
		
	}//method : quizQuestionDelete
	
	public int quizQuestionDeleteExecute(QuizDTO quizDTO) {
		
		String sql = "UPDATE tblQuiz SET state = 0 WHERE num = ? AND subjectSeq = ?";

		try {
			
			pstat = conn.prepareStatement(sql);
			
			pstat.setString(1, quizDTO.getNum());
			pstat.setString(2, quizDTO.getSubjectSeq());
			
			return pstat.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return 0;
		
	}//method : quizQuestionDelete

//=====================================================================================================================================
	
}//Class : LecturerPercentDAO


