package lecturer.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import dto.VwCourseDTO;
import util.DBUtil;

public class LeAttendanceDAO {

	private Connection conn;
	private Statement stat;
	
//-----------------------------------------------------	

	public LeAttendanceDAO() {
		
		try {
			DBUtil util = new DBUtil();
			this.conn = util.connect();
			this.stat = conn.createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("DAO생성자에서 오류");
		}
		
	}//method : LeAttendanceDAO
	
//-----------------------------------------------------	

	public boolean isConnected() {
		
		try {
			return !this.conn.isClosed();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return false;
		
	}
	
//-----------------------------------------------------
	
	public void close() {
		
		try {
			this.conn.close();
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
	}//Method : close
	
//=====================================================================================================================================
	
	public ArrayList<VwCourseDTO> courseNameList(String lecturerSeq) {

		
		try {
			
			String sql = String.format("SELECT * FROM vwCourse WHERE vlecturerSeq = %s", lecturerSeq);
			ResultSet rs = stat.executeQuery(sql);
			
			System.out.println("테스트");
			ArrayList<VwCourseDTO> courseNameList = new ArrayList<VwCourseDTO>();
			
			while (rs.next()) {				
				
				VwCourseDTO courseDTO = new VwCourseDTO();
				courseDTO.setVcourseSeq(rs.getString("VcourseSeq"));
				courseDTO.setVcourseName(rs.getString("VcourseName"));	
				
				System.out.println(rs.getString("VcourseSeq"));
				courseNameList.add(courseDTO);					
			}
			
			return courseNameList;
			
		} catch (SQLException e1) {
			e1.printStackTrace();
			System.out.println("StAttendanceDAO.courseNameList()");
		}
		
		return null;
	}

}//class : LeAttendanceDAO
