package lecturer.service;

import java.util.ArrayList;
import java.util.Scanner;

import dto.WarningDTO;
import lecturer.dao.LeWarningDAO;
import lecturer.view.WarningView;
import util.Cls;

public class LeWarningService implements ILeWarningService {

	private static WarningView view;
	private static Scanner scan;
	
	static {
		view = new WarningView();
		scan = new Scanner(System.in);
	}
	
	@Override
	public void listStudents(String lecturerSeq) {
		
		System.out.println("\t\t\t\t[특별 상담 관리]\n");
		System.out.println("\t==========================================================================");
		System.out.println("\t[번호]\t[이름]\t[출결점수] [강사명]\t\t[과정명]");
		System.out.println("\t==========================================================================");
		LeWarningDAO dao = new LeWarningDAO();
		ArrayList<WarningDTO> studentList = dao.getStudent(lecturerSeq); 
		
		for (WarningDTO student : studentList) {
			
			System.out.printf("\t[%s]\t%s\t%s\t%s\t%s"
								, student.getSTUDENTSEQ()
								, student.getSTUDENTNAME()
								, student.getATTENDANCEGRADE()
								, student.getLECTURERNAME()
								, student.getCOURSENAME());
			System.out.println("\n\t--------------------------------------------------------------------------");
		
		}
		
		
	}

	@Override
	public WarningDTO counsel(String lecturerSeq, String select) {

		Cls.clearScreen();
		
		LeWarningDAO dao = new LeWarningDAO();
		WarningDTO student = dao.getSingleStudent(select); 
		
		System.out.println("\n\t\t\t\t\t[특별상담일지]");
		System.out.println("\n\t==========================================================================\n");
		System.out.printf("\t학생번호\t[%s]\n\n\t학생명\t\t%s\n\n\t[출결점수]\t%s\n\n\t[과정명]\t%s\n"
							, student.getSTUDENTSEQ()
							, student.getSTUDENTNAME()
							, student.getATTENDANCEGRADE()
							, student.getCOURSENAME());
		System.out.println("\n\t=================================상담내용===================================\n");

		view.requireInput();
		String content = scan.nextLine();
		
		student.setCOUNSELINGCONTENT(content);
		return student;
	}

	@Override
	public int insert(WarningDTO student) {

		LeWarningDAO dao = new LeWarningDAO();
		return dao.insert(student);
	}

}
