package lecturer.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

import dto.VwTopFive1DTO;
import lecturer.controller.LecturerController;
import lecturer.dao.LeRecommendationDAO;
import lecturer.view.LecturerRecommendationView;
import util.Cls;

public class LeRecommendationService implements ILeRecommendationService {

	
	private static LecturerRecommendationView lecturerRecommendationView;
	public static LeRecommendationService recomService;
	private Scanner scan;

	public LeRecommendationService() {
		lecturerRecommendationView = new LecturerRecommendationView();
		scan = new Scanner(System.in);
	}

//===============================================================================================================================	
	
	@Override
	public void leRecommendation() {   // 추천서 보기 1~5등까지
		
		LeRecommendationDAO dao = new LeRecommendationDAO();
		
		System.out.println("\t--------------------------------------------------------------------------");
		System.out.println("\t원하는 등수의 추천서를 보시려면 등수번호를 입력해주세요.\n\t(5등 이내만 조회가 가능합니다)");
		System.out.print("\t입력 : ");
		String rank = scan.nextLine();
		System.out.println("\n\t==========================================================================\n");
	
		ArrayList<VwTopFive1DTO> leRecommendation = dao.leRecommendation(rank);
		
		String str = leRecommendation.get(0).getVlecturerrecommendation();
		
		String result = str.substring(0,str.indexOf(",")+1);
		String result2 = str.substring(str.indexOf(",")+1, str.indexOf(".")+1);
		String result3 = str.substring(str.indexOf(".")+1);
		
	
		for(VwTopFive1DTO dto : leRecommendation) {
			Cls.clearScreen();
			System.out.println("\n\t\t\t\t\t\t\t\t추 천 서");
			System.out.printf("\n\n\t\t\t\t\t\t\t\t\t\t\t\t\t%s\n\n\n\n\n\n\n", dto.getVname());
			System.out.println("\t\t\t " + result);
			System.out.printf("\n\t\t\t %s\n",dto.getVcoursename() + result2);
			System.out.println("\n\t\t\t" + result3 + "\n\n\n\n\n");
			System.out.printf("\t\t\t\t\t\t\t\t\t\t\t\t\t%s 교 사\n\n",dto.getVlename());
			System.out.printf("\t\t\t\t\t\t\t%s\r\n\r\n\r\n", dto.getVadminconfirm().replace("0", "쌍 용 교 육 센 터 장"));
			
			SimpleDateFormat date1 = new SimpleDateFormat("yyyy년 MM월 dd일");
			Date date2 = new Date();
			
			String date = date1.format(date2);
			System.out.println("   \t\t\t\t\t\t\t  " + date);
			System.out.println("\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n");
			
			
			//Cls.clearScreen();
		}
		
		dao.close();
		lecturerRecommendationView.pause();
		recommendationList();
		
	}

//===============================================================================================================================

	@Override
	public void recommendationList() {
	      
	      lecturerRecommendationView.title(LecturerRecommendationView.RECOMMENDATION);
	      
	      
	      LeRecommendationDAO dao = new LeRecommendationDAO();
	      
	      ArrayList<VwTopFive1DTO> recommendationList = dao.recommendationList();
	      
	      
	      
	      System.out.println("\t==========================================================================");
	      System.out.printf("\t[과  정  번  호] %s\n", recommendationList.get(0).getVcourseseq());
	      System.out.printf("\t[과    정    명] %s\n", recommendationList.get(1).getVcoursename());
	      System.out.printf("\t[과정 시작 기간] %s\n", recommendationList.get(2).getVstart().substring(0, 10));
	      System.out.printf("\t[과정 종료 기간] %s\n", recommendationList.get(3).getVend().substring(0, 10));
	      System.out.println("\t==========================================================================");
	      System.out.println("\t[번호]\t[이름]\t    [Tel] \t[등록일]\t[성적]\t[사유여부]");
	      
	      for(VwTopFive1DTO dto : recommendationList) {
	      
	         System.out.println("\t--------------------------------------------------------------------------");
	         System.out.printf("\t  %s\t%s\t %s \t%s  \t%s   \t    %s\n",
	                        dto.getVranking()
	                        ,dto.getVname()
	                        ,dto.getVphonenum()
	                        ,dto.getVregistrationdate().substring(0, 10)
	                        ,dto.getVtotal()
	                        ,dto.getVadminconfirm().replace("1", "X").replace("0","O"));
	         
	         
	      }
	      dao.close();
	      
	      lecturerRecommendationView.select();
	      String select = scan.nextLine();
	      
	      boolean loop = true;
	      
	      while(loop)
	      if(select.equals("1")) {
	         leRecommendation();
	      }else if(select.equals("2")) {
	         leRecommendationAddList();
	      }else if(select.equals("0")) {
	         try {
	            LecturerController.main(null);
	         } catch (Exception e) {
	            
	            e.printStackTrace();
	         }
	      }else {
	         System.out.println("잘못된 입력입니다.");
	      }
	      
	      
	      
	   }

//===============================================================================================================================

	@Override
	public void leRecommendationAddList() {

		System.out.println("\t--------------------------------------------------------------------------");
		System.out.println("\t원하시는 학생번호를 입력해 주세요.");
		System.out.print("\t입력 : ");
		String rank = scan.nextLine();
		System.out.println("\n\t==========================================================================\n");
		
		Cls.clearScreen();
		lecturerRecommendationView.title(LecturerRecommendationView.RECOMMENDATION);
		
		System.out.println("\n\t[교육생 정보]");
		System.out.println("\t==========================================================================");
		
		LeRecommendationDAO dao = new LeRecommendationDAO();
		VwTopFive1DTO dto = dao.leRecommendationAddList(rank);
		
		
		if(dto != null) {
			
			System.out.printf("\t[번호]       %s\n",dto.getVranking());
			System.out.printf("\t[이름]       %s\n",dto.getVname());
			System.out.printf("\t[전화번호]   %s\n",dto.getVphonenum());
			System.out.printf("\t[등록일]     %s\n",dto.getVregistrationdate().substring(1, 10));
			System.out.printf("\t[성적]       %s\n",dto.getVtotal());
			System.out.println("\t==========================================================================");
			
		}
		
		
		String lecturerrecommendation = "";
		String adminconfirm = "";
		String sturank = "";
		
		System.out.print("\t추천 사유 입력 : ");
		String temp = scan.nextLine();
		
		//VwLecRecommendationDTO dto1 = dao.leRecommendationAddList(temp);
		
		if(temp != null) {
			lecturerrecommendation =  temp;
		}
		
		System.out.println("\t--------------------------------------------------------------------------");
		System.out.println("\t추천 사유 입력 시 숫자(0)를 입력해주세요.");
		System.out.print("\t입력 : ");
		String temp1 = scan.nextLine();
		
		if(temp1 != null) {
			adminconfirm = temp1;
		}
		
		System.out.println("\t--------------------------------------------------------------------------");
		System.out.println("\t학생의 번호를 다시한번 입력해주세요.");
		System.out.print("\t입력 : ");
		String temp2 = scan.nextLine();
		
		if(temp1 != null) {
			sturank = temp2;
		}
		
		dto = new VwTopFive1DTO();
		dto.setVlecturerrecommendation(lecturerrecommendation);
		dto.setVadminconfirm(adminconfirm);
		dto.setVrank(sturank);
		
		int result = dao.insert(dto);
		
		Cls.clearScreen();
		
		if(result >= 1) {
			
			System.out.println("\t\t\t[추천 사유가 입력되었습니다.]\n\n");
		}else {
			System.out.println("\t\t\t[추천 사유가 입력되지 않았습니다. 다시 한 번 입력해주세요.]\n\n\n\n");
		}

		dao.close();
		lecturerRecommendationView.pause();
		recommendationList();
	}

//===============================================================================================================================

	@Override
	public void leRecommendationAdd() {
	
		
	}

}//class : LeRecommendationService

