package lecturer.service;

public interface ILePercentQuizService {

	void percentQuizManagementMain(String lecturerSeq);

	void percentAdd(String courseSeq, String subjectSeq);
	void percentEdit(String courseSeq, String subjectSeq);
	void percentDelete(String courseSeq, String subjectSeq);

	void quizDateAdd(String courseSeq, String subjectSeq);
	void quizDateEdit(String courseSeq, String subjectSeq);
	void quizDateDelete(String courseSeq, String subjectSeq);

	void quizQuestionAdd(String courseSeq, String subjectSeq);
	void quizQuestionEdit(String courseSeq, String subjectSeq);
	void quizQuestionDelete(String courseSeq, String subjectSeq);

	

}
