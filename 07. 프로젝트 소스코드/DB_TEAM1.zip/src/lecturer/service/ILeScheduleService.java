package lecturer.service;

public interface ILeScheduleService {

	void will();

	void prog();

	//void substu(String temp);

	//void end();

	//void subject(String selcou);
	
}
