package lecturer.service;

import java.util.ArrayList;
import java.util.Scanner;

import dto.VwCountStudentDTO;
import dto.VwCourseDTO;
import dto.VwStudentDTO;
import dto.VwSubjectDTO;
import lecturer.dao.LecturerScheduleDAO;
import lecturer.view.LecturerScheduleView;

public class LeScheduleService implements ILeScheduleService{

	@SuppressWarnings("unused")
	private static Scanner scan;
	private static LecturerScheduleView lecturerScheduleView;
	static {
		scan = new Scanner(System.in);
		lecturerScheduleView = new LecturerScheduleView();
	}
	
	
	//강의 예정
	@Override
	public void will() {
		lecturerScheduleView.title(LecturerScheduleView.SCHEDULESERVICEYET);
		lecturerScheduleView.thickLine();
		
		LecturerScheduleDAO dao = new LecturerScheduleDAO();
		ArrayList<VwCourseDTO> willcoursecheck = dao.willcoursecheck();

			for(VwCourseDTO dto : willcoursecheck) {
				System.out.printf("\t[과정번호] : %s \n", dto.getVcourseSeq());
				lecturerScheduleView.thinLine();
				System.out.printf("\t[과정명] : %s \n", dto.getVcourseName());
				lecturerScheduleView.thinLine();
				System.out.printf("\t[과정시작기간] : %s \n", dto.getVcourseStartDate());
				lecturerScheduleView.thinLine();
				System.out.printf("\t[과정종료기간] : %s \n", dto.getVcourseEndDate());
				lecturerScheduleView.thinLine();
				System.out.printf("\t[강의실] : %s \n", dto.getVclassroom());
				
			}//for
		dao.close();	
		
		
		lecturerScheduleView.thickLine();
		System.out.println("\t[과목번호]\t[과목명]\t\t[과목기간]\t\t[교재명]");
		lecturerScheduleView.thickLine();
				
		LecturerScheduleDAO willdao = new LecturerScheduleDAO();
		ArrayList<VwSubjectDTO> willsubjectcheck = willdao.willsubjectcheck();
		
			
		
		for(VwSubjectDTO dto : willsubjectcheck) {
			System.out.printf("\t[%s]\t%s\t\t%s ~ %s\t%s\n"
								, dto.getVsubjectSeq()
								, dto.getVsubjectName()
								, dto.getVsubjectStartDate()
								, dto.getVsubjectEndDate()
								, dto.getvTextbook());
		}//for	
		dao.close();	
		
		
		
		
		
	}// will()

	@Override
	public void prog() {
		lecturerScheduleView.title(LecturerScheduleView.SCHEDULESERVICECURRENT);
		lecturerScheduleView.thickLine();
		
		//강의중 과정출력
		LecturerScheduleDAO dao = new LecturerScheduleDAO();
		ArrayList<VwCourseDTO> willcoursecheck = dao.willcoursecheck();

			for(VwCourseDTO dto : willcoursecheck) {
				System.out.printf("\t[과정번호] : %s \n", dto.getVcourseSeq());
				lecturerScheduleView.thinLine();
				System.out.printf("\t[과정명] : %s \n", dto.getVcourseName());
				lecturerScheduleView.thinLine();
				System.out.printf("\t[과정시작기간] : %s \n", dto.getVcourseStartDate());
				lecturerScheduleView.thinLine();
				System.out.printf("\t[과정종료기간] : %s \n", dto.getVcourseEndDate());
				lecturerScheduleView.thinLine();
				System.out.printf("\t[강의실] : %s\n", dto.getVclassroom());
			}//for
		dao.close();
		
		//강의중 과정의 총 인원
		LecturerScheduleDAO countdao = new LecturerScheduleDAO();
		ArrayList<VwCountStudentDTO> progcountcheck = countdao.progcountcheck();
			
				lecturerScheduleView.thinLine();
			for(VwCountStudentDTO dto : progcountcheck) {
				
				System.out.printf("\t[등록인원] : 총 %s명 \n", dto.getVcount());
				
		
			}//for
		countdao.close();	
		
		//강의중 과목
		lecturerScheduleView.thickLine();
		System.out.println("\t[과목번호]\t[과목명]\t[과목기간]\t\t[교재명]");
		lecturerScheduleView.thickLine();
				
		LecturerScheduleDAO progdao = new LecturerScheduleDAO();
		ArrayList<VwSubjectDTO> progsubjectcheck = progdao.progsubjectcheck();
		
			
		
		for(VwSubjectDTO dto2 : progsubjectcheck) {
			System.out.printf("\t[%s]\t%s\t%s ~ %s\t%s\n"
								, dto2.getVsubjectSeq()
								, dto2.getVsubjectName()
								, dto2.getVsubjectStartDate()
								, dto2.getVsubjectEndDate()
								, dto2.getvTextbook());
		}//for	
		progdao.close();	

	}//prog()
	
	
	public void selectSubject(String selectnum, String inputnum){
		lecturerScheduleView.title(LecturerScheduleView.SCHEDULESERVICECURRENT);
		lecturerScheduleView.thickLine();
		
		LecturerScheduleDAO dao = new LecturerScheduleDAO();
		ArrayList<VwSubjectDTO> subjectcheck = dao.subjectcheck( selectnum,  inputnum);

			for(VwSubjectDTO dto : subjectcheck) {
				System.out.printf("\t[과목번호] : %s\n\t[과목명] : %s \n\t[과목시작기간] : %s \n\t[과목종료기간] %s \n\t[교재명] : %s \n\t[강사명] :  %s\n"
						,dto.getVsubjectSeq(), 
						dto.getVsubjectName(), 
						dto.getVsubjectStartDate(), 
						dto.getVsubjectEndDate(), 
						dto.getvTextbook(), 
						dto.getVlecturerseq());
			}//for	
			
		dao.close();	
	}
	
	public void selectSubjectcount(String selectnum, String inputnum){
		//강의중 과정의 총 인원
			LecturerScheduleDAO countdao = new LecturerScheduleDAO();
			ArrayList<VwCountStudentDTO> progcountcheck = countdao.progcountcheck();
					
			lecturerScheduleView.thinLine();
				for(VwCountStudentDTO dto : progcountcheck) {
						
				System.out.printf("\t[등록인원] : 총 %s명 \n", dto.getVcount());
						
				}
		
	}//selectSubjectcount
	
	public void coursestudent(String selectnum, String inputnum) {
		lecturerScheduleView.thickLine();
		System.out.println("\t[교육생번호]\t[교육생이름]\t[TEL]\t[등록일]\t\t[상태]");
		lecturerScheduleView.thickLine();
		
		
		//DB작업 > DAO위임(SELECT)
		LecturerScheduleDAO dao = new LecturerScheduleDAO();
		ArrayList<VwStudentDTO> courseStudent = dao.courseStudent(selectnum,  inputnum);
		
	
		for(VwStudentDTO dto : courseStudent) {
			System.out.printf("\t[%s] ", dto.getVstudentSeq());
			
			System.out.printf("\t%s ", dto.getVstudentName());
			
			System.out.printf("\t%s ", dto.getVphoneNum());
			
			System.out.printf("\t%s ", dto.getVregistrationtime());
			
			System.out.printf("\t%s ", dto.getVstudentstatus());
			
			System.out.print("\t세부사항 참조\n");
			
		}
		lecturerScheduleView.thinLine();
		
		dao.close();
		
	
		
	}//coursestudent
	

}
