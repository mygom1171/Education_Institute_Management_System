package admin.service;

public interface IAdStudentService {

}
