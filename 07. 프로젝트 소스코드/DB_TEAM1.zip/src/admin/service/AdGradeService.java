package admin.service;

import java.util.ArrayList;
import java.util.Scanner;

import admin.dao.AdminGradeDAO;
import admin.view.AdminGradeView;
import dto.StudentInfoDTO;
import dto.VwcouingdateDTO;
import dto.VwcouroomlecDTO;
import dto.VwcousubDTO;
import dto.VwcousubstutexlecDTO;
import dto.VwsinfograDTO;
import dto.VwstucoutempDTO;
import dto.VwsubcouroomlecDTO;
import dto.VwsubgraquizDTO;

public class AdGradeService implements IAdGradeService {

	private static Scanner scan;
	private static AdminGradeView adminGradeView;
	static {
		scan = new Scanner(System.in);
		adminGradeView = new AdminGradeView();
	}

	
	
	public static void gradeByCourse() {
		
		boolean loop = true;
		while(loop) {
			
			System.out.println("\t\t\t\t[과정별 시험 및 성적 관리]");
			System.out.println();
			System.out.println("\t[진행중인 과정]");
			adminGradeView.title(AdminGradeView.DOUBLELINE);
			
			AdminGradeDAO dao = new AdminGradeDAO(); 
			
			ArrayList<VwcouingdateDTO> list = new ArrayList<VwcouingdateDTO>();
			
			list = dao.couIngList();
			System.out.println("\t[과정번호]\t과정명");
			adminGradeView.title(AdminGradeView.DOUBLELINE);
			for(VwcouingdateDTO dto : list) {
				adminGradeView.title(AdminGradeView.LINE);
				System.out.println(String.format("\t[%s]\t%s", dto.getVcouseq(),dto.getVcouname()));
				
			}
			adminGradeView.title(AdminGradeView.DOUBLELINE);
			
			dao.close();

			adminGradeView.requireSelct();	
			String couseq = scan.nextLine();
			
			if(couseq.equals("0")) {
				loop = false;
			}else {
				System.out.println("\t해당 과정의 세부사항 페이지로 이동합니다.");
				adminGradeView.pressEnter();
				AdGradeService.gradeBySubject(couseq);
			}
			
		}
		
		
		
	}



	private static void gradeBySubject(String couseq) {
		boolean loop = true;
		while(loop) {
			
			System.out.println("\t\t\t\t[과정별 시험 및 성적 관리]");
			System.out.println();
			AdminGradeDAO dao = new AdminGradeDAO(); 
			
			VwcouroomlecDTO coudto = new VwcouroomlecDTO();
			ArrayList<VwcousubDTO> sublist = new ArrayList<VwcousubDTO>();
			coudto = dao.gradeBySubject(couseq);
			sublist = dao.vwcousub(couseq);
			adminGradeView.title(AdminGradeView.DOUBLELINE);
			System.out.println("\t과정명\t" + coudto.getVcouname());
			adminGradeView.title(AdminGradeView.LINE);
			System.out.println("\t과정기간\t" + coudto.getVcoustart()+"~"+coudto.getVcouend());
			adminGradeView.title(AdminGradeView.LINE);
			System.out.println("\t강의실명\t" + coudto.getVroomname());
			adminGradeView.title(AdminGradeView.LINE);
			System.out.println("\t교사명\t"+coudto.getVlecname());
			adminGradeView.title(AdminGradeView.DOUBLELINE);
			
			System.out.println();
			adminGradeView.title(AdminGradeView.DOUBLELINE);
			System.out.println("\t[과목번호]\t과목명\t\t\t\t\t성적 등록 여부\t시험문제 등록여부");
			
			for(VwcousubDTO dto : sublist) {
				adminGradeView.title(AdminGradeView.LINE);
				System.out.println(String.format("\t[%s]\t%-30s\t\t\t%10s\t%s", dto.getVsubseq(),
																	dto.getVsubname(),
																	subRegist(dto.getVsubseq()),
																	quizRegist(dto.getVsubseq())));
			}
			adminGradeView.title(AdminGradeView.DOUBLELINE);
					
			System.out.println("\t과목 번호를 입력하면 해당 과목의 성적 페이지로 이동합니다.");
			
			adminGradeView.requireSelct();
			String select = scan.nextLine();
			if(select.equals("0")) {
				loop = false;
			}else{
				System.out.println("\t성적 페이지로 이동합니다.");
				adminGradeView.pressEnter();
				AdGradeService.graeachStudent(couseq,select);
			}
			
			dao.close();
		}
		
		
		
	}



	private static String quizRegist(String vsubseq) {
		
		AdminGradeDAO dao = new AdminGradeDAO(); 		
		String cnt = dao.cntQuiz(vsubseq);
		
		return cnt;
	}



	private static String subRegist(String vsubseq) {
		
		AdminGradeDAO dao = new AdminGradeDAO();	
		String cnt = dao.cntSubRegist(vsubseq);
		
		return cnt;
		
		
	}



	private static void graeachStudent(String couseq,String subseq) {
		
		boolean loop = true;

		while(loop) {
			
			System.out.println("\t\t\t\t[과정별 시험 및 성적 관리]");
			System.out.println();
			AdminGradeDAO dao = new AdminGradeDAO();
			
			VwsubcouroomlecDTO coudto = new VwsubcouroomlecDTO();
			ArrayList<VwsinfograDTO>sinlist = new ArrayList<VwsinfograDTO>();
			coudto = dao.vwsubcouroomlec(couseq,subseq);
			sinlist = dao.vwsinfogra(couseq,subseq);
			
			System.out.println("\t[과목 정보]\t");
			adminGradeView.title(AdminGradeView.DOUBLELINE);
			System.out.println("\t[과목명]\t"+coudto.getVsubname());
			adminGradeView.title(AdminGradeView.LINE);
			System.out.println("\t[과목 기간]\t"+coudto.getVsubstart()+"~"+coudto.getVsubend());
			adminGradeView.title(AdminGradeView.LINE);
			System.out.println("\t[교재명]\t"+coudto.getVtextname());
			adminGradeView.title(AdminGradeView.LINE);
			System.out.println("\t[교사명]\t"+coudto.getVlecname());
			adminGradeView.title(AdminGradeView.DOUBLELINE);
			
			int i=0;
			for(VwsinfograDTO dto : sinlist) {
				i++;
				System.out.println(String.format("\t교육생%02d\t", i));
				adminGradeView.title(AdminGradeView.DOUBLELINE);
				System.out.println("\t이름\t\t"+dto.getVstuname());
				adminGradeView.title(AdminGradeView.LINE);
				System.out.println("\t주민번호 뒷자리\t"+dto.getVrnum());
				adminGradeView.title(AdminGradeView.LINE);
				System.out.println("\t필기\t\t"+dto.getVgraprac());
				adminGradeView.title(AdminGradeView.LINE);
				System.out.println("\t실기\t\t"+dto.getVgraprac());
				adminGradeView.title(AdminGradeView.LINE);
				System.out.println("\t출결\t\t"+dto.getVgraatt());
				adminGradeView.title(AdminGradeView.DOUBLELINE);
				System.out.println();				
			}
			dao.close();
			
			System.out.println("[0] 돌아가기");
			adminGradeView.pressEnter();
			adminGradeView.requireSelct();
			String select = scan.nextLine();
			if(select.equals("0")) {
				loop = false;
			}
			
		}
		
		
		
		
		
	}



	public static void gradeByName() {
		
		@SuppressWarnings("unused")
		boolean loop = true;
		
		{
			System.out.println("\t\t\t\t[교육생별 시험 및 성적 관리]");
			adminGradeView.title(AdminGradeView.DOUBLELINE);
			System.out.println("\t교육생 이름을 입력해주십시오.");
			System.out.println();
			System.out.println("\t입력[한글] :");
			adminGradeView.title(AdminGradeView.DOUBLELINE);
			
			
			String name = scan.nextLine();
			
			AdminGradeDAO dao = new AdminGradeDAO();
			ArrayList<StudentInfoDTO> list = new ArrayList<StudentInfoDTO>();
			list = dao.studentInfoByName(name);
			
			System.out.println("\t번호\t이름\t주민번호 뒷자리\t\t전화번호");
			for(StudentInfoDTO dto : list) {
				adminGradeView.title(AdminGradeView.LINE);
				System.out.println(String.format("[%s]\t%s\t%s\t\t%s", 
							dto.getSeq(),dto.getName(),dto.getRegistrationNum(),
							dto.getPhoneNum()));
				
			}
			adminGradeView.title(AdminGradeView.DOUBLELINE);
			
			System.out.println("[0]뒤로 가기.");
			adminGradeView.requireSelct();
			adminGradeView.title(AdminGradeView.LINE);
		
			String select = scan.nextLine();
			if(select.equals("0")) {
				
				loop = false;
				
			}else {
				
				AdGradeService.subInfo(select);
				
			}

		}
		
	}



	private static void subInfo(String stuinfoseq) {
		boolean loop = true;
		
		while(loop) {
			
			System.out.println("\t\t\t\t[교육생별 시험 및 성적 관리]");
			
			AdminGradeDAO dao = new AdminGradeDAO();
			ArrayList<VwstucoutempDTO>tempdtolist = new ArrayList<VwstucoutempDTO>();
			
			tempdtolist=dao.vwstucoutemp(stuinfoseq);
			
			for(VwstucoutempDTO dto : tempdtolist) {
				System.out.println("\t[교육생\t"+dto.getVsinfoseq()+"]");
				adminGradeView.title(AdminGradeView.DOUBLELINE);
				System.out.println("\t주민번호 뒷자리\t"+dto.getVsturnum());
				adminGradeView.title(AdminGradeView.LINE);
				System.out.println("\t과정명\t"+dto.getVcouname());
				adminGradeView.title(AdminGradeView.LINE);
				System.out.println("\t과정기간\t"+dto.getVcoustart()+"~"+dto.getVcouend());
				adminGradeView.title(AdminGradeView.LINE);
				System.out.println("\t강의실\t"+dto.getVroomname());
				adminGradeView.title(AdminGradeView.DOUBLELINE);
				
				ArrayList<VwcousubstutexlecDTO> list = new ArrayList<VwcousubstutexlecDTO>();
				list = dao.vwcousubstutexlec(dto.getVcouseq(),stuinfoseq);
				
				for(VwcousubstutexlecDTO subdto : list) {
					System.out.println("\t과목\t"+subdto.getVsubseq());
					adminGradeView.title(AdminGradeView.DOUBLELINE);
					System.out.println("\t과목명\t"+subdto.getVsubname());
					adminGradeView.title(AdminGradeView.LINE);
					System.out.println("\t과목기간\t"+subdto.getVsubstart()+"~"+subdto.getVsubend());
					adminGradeView.title(AdminGradeView.LINE);
					System.out.println("\t교재명\t"+subdto.getVtextname());
					adminGradeView.title(AdminGradeView.LINE);
					System.out.println("\t교사명\t"+subdto.getVlecname());
					
					
				}
			}
				
				
			
			dao.close();
			
			adminGradeView.title(AdminGradeView.DOUBLELINE);
			
			System.out.println("\t과목 번호를 입력하면 해당 과목의 성적 페이지로 이동합니다.");
			System.out.println("\t[0]돌아가기");
			adminGradeView.requireSelct();
			String subseq = scan.nextLine();
			
			if(subseq.equals("0")) {
				loop=false;
			}else {
				AdGradeService.quizGradPage(stuinfoseq,subseq);
				
			}
			
						
		}
		
		
		
		
	}



	private static void quizGradPage(String stuinfoseq, String subseq) {
		
		boolean loop = true;
		while(loop) {
			
			System.out.println("\t\t\t\t[교육생별 시험 및 성적 관리]");
			AdminGradeDAO dao = new AdminGradeDAO();
			VwsubgraquizDTO dto = dao.vwsubgraquiz(stuinfoseq,subseq);
			
			System.out.println("\t[과목]\t"+dto.getVsubseq());
			adminGradeView.title(AdminGradeView.DOUBLELINE);
			System.out.println("\t과목명\t" + dto.getVsubnanme());
			adminGradeView.title(AdminGradeView.LINE);
			System.out.println("\t과목 기간\t" + dto.getVsubstart()+"~"+dto.getVsubend());
			adminGradeView.title(AdminGradeView.LINE);
			System.out.println("\t교재명\t"+dto.getVtextname());
			adminGradeView.title(AdminGradeView.LINE);
			System.out.println("\t교사명\t"+dto.getVlecturername());
			adminGradeView.title(AdminGradeView.LINE);
			System.out.println("\t배점 정보 \t필기배점\t"+dto.getVsubwrittenpercent()+"\t실기배점"+dto.getVsubpracpercent());
			adminGradeView.title(AdminGradeView.LINE);
			System.out.println("\t성적 정보 \t필기\t"+dto.getVgrawritten()+"\t실기"+dto.getVgrapractical()+"\t");
			adminGradeView.title(AdminGradeView.LINE);
			System.out.println("\t시험 날짜\t"+dto.getVquizdate());
			adminGradeView.title(AdminGradeView.DOUBLELINE);
			
			System.out.println("\t[0]돌아가기 ");
			adminGradeView.requireSelct();
			@SuppressWarnings("unused")
			String temp = scan.nextLine();
			
			if(scan.nextLine().equals("0")) {
				System.out.println("\t이전 화면으로 돌아갑니다.");
				adminGradeView.pressEnter();
				loop = false;
			}
		}
		
	}

}//class : AdGradeService
