package admin.service;

public interface IAdCourseService {
	
	void courseAdd();	
	void courseList();	
	void courseEdit();	
	void courseDelete();	
		
	void subjectAdd(String courseSeq, String courseLecturer);
	void subjectList(String courseSeq);
	void subjectEdit(String courseSeq, String courseLecturer);
	void subjectDelete(String courseSeq);
	
	void courseStudentList(String courseSeq);
	
}
