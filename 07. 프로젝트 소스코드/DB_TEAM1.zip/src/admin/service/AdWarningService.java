package admin.service;

import java.util.ArrayList;

import admin.dao.AdWarningDAO;
import admin.view.AdministratorWarningView;
import dto.WarningDTO;
import util.Cls;

public class AdWarningService implements IAdWarningService {

	private static AdministratorWarningView administratorWarningView;
	
	static {
		administratorWarningView = new AdministratorWarningView();
	}
	
	@Override
	public void listStudents() {
		
		Cls.clearScreen();
		
		System.out.println("\t\t\t\t[특별 상담 관리]");
		System.out.println("\n\t==========================================================================");
		System.out.println("\t[번호]\t[이름]\t[출결점수]\t[강사명]\t[과정명]");
		System.out.println("\t==========================================================================");
		AdWarningDAO dao = new AdWarningDAO();
		ArrayList<WarningDTO> studentList = dao.getStudent(); 
		
		for (WarningDTO student : studentList) {
			
			System.out.printf("\t[%s]\t%s\t%s\t\t%s\t%s"
								, student.getSTUDENTSEQ()
								, student.getSTUDENTNAME()
								, student.getATTENDANCEGRADE()
								, student.getLECTURERNAME()
								, student.getCOURSENAME());
			System.out.println("\n\t--------------------------------------------------------------------------");
		
		}
	}

	@Override
	public void notifyLecturer() {
		
		AdWarningDAO dao = new AdWarningDAO();
		ArrayList<WarningDTO> studentList = dao.getStudent(); 
		
		dao.notifyLecturer(studentList);
		
		administratorWarningView.pause(AdministratorWarningView.WARNING);
	}

}



