package admin.service;

//import java.util.ArrayList;
//
//import dto.WarningDTO;

public interface IAdWarningService {

	void listStudents();

	void notifyLecturer();


}
