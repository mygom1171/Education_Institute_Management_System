package admin.view;

import java.util.Scanner;

import admin.controller.AdministratorController;
import admin.service.AdLecturerInfoService;

public class AdministratorLecturerManageView {
	
	//교사 계정 관리
	public final static int ADDLECTURER = 200;
	public final static int LECTURERINFO = 201;
	public final static int DETAILLECTURER= 202;
	public final static int UPDATELECTURER = 203;
	public final static int UPDATELECTURERNAME = 204;
	public final static int UPDATELECTURERREG = 205;
	public final static int UPDATELECTURERTEL = 206;
	public final static int UPDATELECTURERSUBJECT = 207;
	public final static int LECTURERCOURSEINFO = 208;
	public final static int SELECTCOURSE = 209;
	public final static int SELECTSUBJECT = 210;	
	
	private static Scanner scan;
	
	static {
		scan = new Scanner(System.in);
	}
	
//라인
//==================================================================================================================================
			
	public void thinLine() {
		
		System.out.println("\t--------------------------------------------------------------------------");
		
	}//method : line
	
	public void thickLine() {
		
		System.out.println("\t==========================================================================");
		
	}//method : line
	
	
	
//관리자 메뉴 메인	
//==================================================================================================================================
	
	public void begin() {
		
		System.out.println("\t\t\t\t[쌍용교육센터 - 관리자]");
		
	}//Method : begin
	
	public void menu() {
		
		System.out.println("\n\t==========================================================================\n");

		System.out.println("\t\t\t\t[1] 기초 정보 관리\n");
		System.out.println("\t\t\t\t[2] 교사 계정 관리\n");
		System.out.println("\t\t\t\t[3] 개설 과정 관리\n");
		System.out.println("\t\t\t\t[4] 교육생 관리\n");
		System.out.println("\t\t\t\t[5] 성적 관리\n");
		System.out.println("\t\t\t\t[6] 출결 관리\n");
		System.out.println("\t\t\t\t[7] 추천서 관리\n\n");
		
		System.out.println("\t\t\t\t[0] 로그아웃\n");
		
		System.out.println("\t--------------------------------------------------------------------------\n");
		
		System.out.println("\t\t\t\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t\t\t\t입력: ");
		
	}//Method : menu
	
//==================================================================================================================================


	
//교사 계정 관리	
//==================================================================================================================================
	
	public void lecturerBasicInfoSelect() {
		// TODO Auto-generated method stub
		
	}
	
	public void lecturerBasicInfomenu() {
		
		System.out.println("\t\t\t\t[교사 관리]");
		
		System.out.println("\n\t==========================================================================\n");
		System.out.println("\t\t\t\t[1] 교사 추가\n");
		System.out.println("\t\t\t\t[2] 교사 정보 조회\n");
		
		System.out.println("\t\t\t\t[0] 돌아가기\n");
		
		System.out.println("\t--------------------------------------------------------------------------\n");
		
		System.out.println("\t\t\t\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t\t\t\t입력: ");
		
		
	}
	
	public void lecturerBasicInfoUpdate() {
		
		System.out.println("\n\t==========================================================================\n");
		System.out.println("\t\t\t\t[1] 수정\n");
		System.out.println("\t\t\t\t[2] 삭제\n");
		
		System.out.println("\t\t\t\t[0] 돌아가기\n");
		
		System.out.println("\t--------------------------------------------------------------------------\n");
		
		System.out.println("\t\t\t\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t\t\t\t입력: ");
	}
	
	public void avlbSubjectSelect() {
		
		
		
		System.out.println("\n\t==========================================================================\n");
		System.out.println("\t\t\t\t[*] 수정하기");
		System.out.println("\t\t\t\t[#] 담당과정 확인하기");
		System.out.println("\t\t\t\t[0] 돌아가기");
		System.out.println("\t--------------------------------------------------------------------------\n");
//		System.out.println("\t\t\t\t[ ] 안의 번호를 입력하십시오");
//		System.out.print("\t\t\t\t입력: ");
		
		
	}
	
	public String editchoice(String selectnum) {
		System.out.println(" ");
		System.out.println("\t--------------------------------------------------------------------------");
		System.out.println("\t\t\t\t수정할 항목을 선택하십시오.");
		System.out.println("\t\t\t\t[1] 교사이름");
		System.out.println("\t\t\t\t[2] 주민번호 뒷자리");
		System.out.println("\t\t\t\t[3] 전화번호");
		System.out.println("\t\t\t\t[4] 강의 가능 과목");
		System.out.println("\t\t\t\t[0] 돌아가기");
		System.out.println("\t--------------------------------------------------------------------------");
		
		System.out.println("\t\t\t\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t\t\t\t입력: ");
		
		String select = scan.nextLine();
		
		@SuppressWarnings("unused")
		String editElement = "";
		
		if(select.equals("1")) {
			
			editElement = "1";
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t\t\t\t교사이름 수정 페이지로 이동합니다\n");
			System.out.println("\t\t\t\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			
			AdLecturerInfoService.editLecturerName(selectnum);
			editchoice(selectnum);
			
		} else if (select.equals("2")) {
			
			editElement = "2";
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t\t\t\t주민번호 수정 페이지로 이동합니다\n");
			System.out.println("\t\t\t\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			
			AdLecturerInfoService.editLecturerssn(selectnum);
			editchoice(selectnum);
			
		} else if (select.equals("3")) {
			
			editElement = "3";
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t\t\t\t전화번호 수정 페이지로 이동합니다\n");
			System.out.println("\t\t\t\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			AdLecturerInfoService.editLecturertel(selectnum);
			editchoice(selectnum);
			
		} else if (select.equals("4")) {
			
			editElement = "4";
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t\t\t\t강의가능 과목 수정 페이지로 이동합니다\n");
			System.out.println("\t\t\t\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			AdLecturerInfoService.editLeSbChoice(selectnum);
			
			AdministratorController.detailLecturer(selectnum);
			
		
		} else if (select.equals("0")) {
			
			editElement = "0";
			System.out.println("\t--------------------------------------------------------------------------");
			System.out.println("\t\t\t\t이전 화면으로 이동합니다\n");
			System.out.println("\t\t\t\t계속하시려면 ENTER키를 누르십시오");
			
			scan.nextLine();
			AdministratorController.detailLecturer(selectnum);
			
		}
		return null;
	}
	
	
//------------------------------------------------------------------------------------------------------------------------	
	//교사추가시 가능과목선택
	public void addavlbsubject() {
		
		System.out.println("\t==========================================================================");
		System.out.println("\t\t\t\t[ ] 안의 과목 번호를 입력하십시오");
		System.out.print("\t\t\t\t입력: ");
		
	}//method : addCourseName01
//==================================================================================================================================	
	
//------------------------------------------------------------------------------------------------------------------------	
	//교사추가시 가능과목선택
	public void plusAddAvlb() {
			
		System.out.println("\t==========================================================================");
		System.out.println("\t\t\t\t[+] 과목 더 추가하기");
		System.out.println("\t\t\t\t[0] 돌아가기");
		System.out.println("\t--------------------------------------------------------------------------\n");
		System.out.println("\t\t\t\t[ ] 안의 번호를 입력하십시오");
		System.out.print("\t\t\t\t입력: ");
			
	}//method : addCourseName01
//==================================================================================================================================	
	
	

//타이틀	
//==================================================================================================================================		
	
	public void title(int n) {
		
		switch(n)
		{
	
		//교사 계정 관리	
		case AdministratorLecturerManageView.ADDLECTURER : 
			System.out.println("\t\t\t\t[교사 추가]"); 
			break;
		case AdministratorLecturerManageView.LECTURERINFO : 
			System.out.println("\t\t\t\t[교사 정보]"); 
			break;
		case AdministratorLecturerManageView.DETAILLECTURER : 
			System.out.println("\t\t\t\t[교사 상세정보]"); 
			break;
		case AdministratorLecturerManageView.UPDATELECTURER : 
			System.out.println("\t\t\t\t[교사 정보 수정]"); 
			break;
		case AdministratorLecturerManageView.UPDATELECTURERNAME : 
			System.out.println("\t\t\t\t[교사 이름 수정]"); 
			break;
		case AdministratorLecturerManageView.UPDATELECTURERREG : 
			System.out.println("\t\t\t\t[교사 주민번호 수정]"); 
			break;
		case AdministratorLecturerManageView.UPDATELECTURERTEL : 
			System.out.println("\t\t\t\t[교사 전화번호 수정"); 
			break;
		case AdministratorLecturerManageView.UPDATELECTURERSUBJECT : 
			System.out.println("\t\t\t\t[교사 가능과목 수정]"); 
			break;
		case AdministratorLecturerManageView.LECTURERCOURSEINFO : 
			System.out.println("\t\t\t\t[교사 과정 확인]"); 
			break;
			
		}//switch End
				
	}//Method : title

//==================================================================================================================================
	
	public void enterpause() {
		System.out.println("\t==========================================================================\n");
		System.out.println("\t\t\t\t계속하려면 엔터를 입력하세요.");

		scan.nextLine();
		
	}
	
	public void scanpause() {
		System.out.println("\t==========================================================================\n");
		System.out.println("\t\t\t\t[ ] 안의 번호를 입력하세요");
		System.out.print("\t\t\t\t입력 : ");
		
		@SuppressWarnings("unused")
		String beforeSeq = scan.nextLine();

	}
	
	public void mainpause() {
		System.out.println("\t==========================================================================\n");
		System.out.println("\t\t\t\t관리자메뉴로 가시려면 엔터를 입력하세요.");

		scan.nextLine();
		
		AdministratorController.main();
	}
	
	public void pause() {
		System.out.println("\t==========================================================================\n");
		System.out.println("\t\t\t\t계속하려면 엔터를 입력하세요.");

		scan.nextLine();
		
	}
	
}//Class : AdministratorView

