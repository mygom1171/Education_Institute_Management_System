package admin.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import dto.*;
import util.DBUtil;

public class AdminStudentDAO {

	private Connection conn;
	private Statement stat;
	private PreparedStatement pstat;

	public AdminStudentDAO() {
		
		try {
			DBUtil util = new DBUtil();
			this.conn = util.connect();
			this.stat = conn.createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("DAO생성자에서 오류");
		}
	}
//-----------------------------------------------------		
	public boolean isConnected() {
		
		try {
			return !this.conn.isClosed();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return false;
		
	}
	
//-----------------------------------------------------
	public void close() {
		
		try {
			this.conn.close();
		} catch (Exception e) {
			System.out.println(e.toString());
		}
	}
	public void studentAdd(String name, String rnum, String pnum) {
		String sql = "INSERT INTO tblstudentinfo values(TBLSTUDENTINFOSEQ.nextval,?,?,?,SYSDATE,default)";
		
		try {
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, name);
			pstat.setString(2, rnum);
			pstat.setString(3, pnum);
			
			pstat.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
//-----------------------------------------------------
	public ArrayList<StudentInfoDTO> searchByName(String nextLine) {
		String sql = "SELECT * FROM vwtblstudentinfo WHERE name like '%'||?||'%'";
		
		try {
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, nextLine);
			
			
			ResultSet rs = pstat.executeQuery();
								
			ArrayList<StudentInfoDTO> list = new ArrayList<StudentInfoDTO>();
		
			while(rs.next()) {
				//레코드 1개 -> DTO 1개
				StudentInfoDTO dto = new StudentInfoDTO();
				
				dto.setName(rs.getString("name"));
				dto.setPhoneNum(rs.getString("phoneNum"));
				dto.setRegistrationDate(rs.getString("registrationDate"));
				dto.setRegistrationNum(rs.getString("registrationNum"));
				dto.setDelete(rs.getString("state"));
				dto.setSeq(rs.getString("seq"));

				list.add(dto);
			}
			
			return list;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
	}
//-----------------------------------------------------	
	public StudentInfoDTO studentInfoBySeq(String nextLine) {
		String sql = "SELECT * FROM vwtblstudentinfo WHERE seq = ?";
		
		try {
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, nextLine);
			
			ResultSet rs = pstat.executeQuery();
								
			if(rs.next()) {
				StudentInfoDTO dto = new StudentInfoDTO();
				dto.setName(rs.getString("name"));
				dto.setPhoneNum(rs.getString("phoneNum"));
				dto.setRegistrationDate(rs.getString("registrationDate"));
				dto.setRegistrationNum(rs.getString("registrationNum"));
				dto.setDelete(rs.getString("state"));
				dto.setSeq(rs.getString("seq"));

				return dto;
				
			}
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
	}
//-----------------------------------------------------	
	public VwstucouDTO courseInfo(String nextLine) {
		String sql = "SELECT * FROM vwstucou WHERE vstuinseq =?";
		
		try {
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, nextLine);
			
			ResultSet rs = pstat.executeQuery();
								
			if(rs.next()) {
				
								
				
				
				VwstucouDTO dto = new VwstucouDTO();
				dto.setVcouend(rs.getString("vcouend"));
				dto.setVcouname(rs.getString("vcouname"));
				dto.setVcouseq(rs.getString("vcouseq"));
				dto.setVcoustart(rs.getString("vcoustart"));
				dto.setVstuinseq(rs.getString("vstuinseq"));
				dto.setVstuname(rs.getString("vstuname"));
				dto.setVsturnum(rs.getString("vsturnum"));
				dto.setVstupnum(rs.getString("vstupnum"));
				dto.setVstustatus(rs.getString("vstustatus"));
				dto.setVstuinrdate(rs.getString("vstuinrdate"));
				dto.setVstustatusdate(rs.getString("vstustatusdate"));				
				return dto;
				
			}
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
	}
//-----------------------------------------------------
	public void modifyStatus(String select, String date, VwstucouDTO coudto) {
		String sql = "UPDATE tblstudent SET status = ?,statusdate = sysdate WHERE seq = ? ";
		String status = "";
		if(select.equals("1")) {
			status = "3";
		}else if(select .equals("2")) {
			status = "2";
		}else {
			status = "1";
		}
		
		try {
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, status);
			pstat.setString(2, coudto.getVstuinseq());
			pstat.executeUpdate();			
			
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
//-----------------------------------------------------
	public void studentinfoDelete(String vstuinseq) {
		String sql = "UPDATE tblstudentinfo SET state = '0' WHERE seq = ? ";
		
		try {
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, vstuinseq);
			pstat.executeUpdate();			
			
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
//-----------------------------------------------------
	public void modifyRdate(VwstucouDTO coudto, String nextLine) {
		String sql = "UPDATE tblstudent SET registrationtime = ? WHERE seq = ? ";
		
		try {
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, nextLine);
			pstat.setString(2, coudto.getVstuinseq());
			pstat.executeUpdate();			
			
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
//-----------------------------------------------------
	public void modifyPnum(VwstucouDTO coudto, String nextLine) {
		String sql = "UPDATE tblstudentinfo SET phonenum = ? WHERE seq = ? ";
		
		try {
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, nextLine);
			pstat.setString(2, coudto.getVstuinseq());
			pstat.executeUpdate();			
			
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
//-----------------------------------------------------
	public void modifyName(VwstucouDTO coudto, String nextLine) {
		String sql = "UPDATE tblstudentinfo SET name = ? WHERE seq = ? ";
		
		try {
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, nextLine);
			pstat.setString(2, coudto.getVstuinseq());
			pstat.executeUpdate();			
			
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
//-----------------------------------------------------
	public void modifyRnum(VwstucouDTO coudto, String nextLine) {
		String sql = "UPDATE tblstudentinfo SET registrationnum = ? WHERE seq = ? ";
		
		try {
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, nextLine);
			pstat.setString(2, coudto.getVstuinseq());
			pstat.executeUpdate();			
			
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
//-----------------------------------------------------
	public ArrayList<VwcoustuDTO> vwCouStu() {
		String sql = "SELECT * FROM vwcoustu";
		
		try {
			stat = conn.createStatement();
			ResultSet rs = stat.executeQuery(sql);
			ArrayList<VwcoustuDTO>list = new ArrayList<VwcoustuDTO>();
			
			while(rs.next()) {
				//레코드 1개 -> DTO 1개
				VwcoustuDTO dto = new VwcoustuDTO();
				dto.setVname(rs.getString("vname"));
				dto.setVseq(rs.getString("vseq"));
				list.add(dto);
			}
			return list;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
	}
//-----------------------------------------------------
	public ArrayList<VwstucouDTO> selCouStuList(String nextLine) {
		String sql = "SELECT * FROM vwstucou WHERE vcouseq =?";
		
		try {
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, nextLine);
			
			ResultSet rs = pstat.executeQuery();
			ArrayList<VwstucouDTO> list = new ArrayList<VwstucouDTO>();				
			while(rs.next()) {
				//레코드 1개 -> DTO 1개
				VwstucouDTO dto = new VwstucouDTO();
				dto.setVcouend(rs.getString("vcouend"));
				dto.setVcouname(rs.getString("vcouname"));
				dto.setVcouseq(rs.getString("vcouseq"));
				dto.setVcoustart(rs.getString("vcoustart"));
				dto.setVstuinseq(rs.getString("vstuinseq"));
				dto.setVstuname(rs.getString("vstuname"));
				dto.setVsturnum(rs.getString("vsturnum"));
				dto.setVstupnum(rs.getString("vstupnum"));
				dto.setVstustatus(rs.getString("vstustatus"));
				dto.setVstuinrdate(rs.getString("vstuinrdate"));
				dto.setVstustatusdate(rs.getString("vstustatusdate"));				
				dto.setVstuseq(rs.getString("vstuseq"));
				list.add(dto);
			}
			
			return list;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return null;
	}
	public ArrayList<VwBeforeCouDTO> vwbeforecou() {
		
		String sql = "select * from vwbeforecou";
		ArrayList<VwBeforeCouDTO> list = new ArrayList<VwBeforeCouDTO>();
		
		try {
			ResultSet rs =	stat.executeQuery(sql);
			
			while(rs.next()) {
				VwBeforeCouDTO dto = new VwBeforeCouDTO();
				
				dto.setVcouname(rs.getString("vcouname"));
				dto.setVcouseq(rs.getString("vcouseq"));
				
				list.add(dto);
			}
			
			return list;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		
		return null;
	}
	
	public void stuInfoCourseAdd(VwstucouDTO coudto, String select) {
		String sql = "insert into tblstudent values(studentseq.nextval,?,?,sysdate,4,sysdate)";
				
		//		?  ?  stu,cou
		
		
		try {
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, coudto.getVstuinseq());
			pstat.setString(2, select);
			pstat.executeUpdate();	
						
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public ArrayList<VwDelListDTO> vwDelList(VwstucouDTO coudto) {
		String sql = "select * from vwdellist where vstuinfoseq=?";
		
		try {
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, coudto.getVstuinseq());
			ResultSet rs = pstat.executeQuery();
			ArrayList<VwDelListDTO>list = new ArrayList<VwDelListDTO>();
			
			while(rs.next()) {
				VwDelListDTO dto = new VwDelListDTO();
				dto.setVcouend(rs.getString("vcouend"));
				dto.setVcouname(rs.getString("vcouname"));
				dto.setVcouseq(rs.getString("vcouseq"));
				dto.setVcoustart(rs.getString("vcoustart"));
				
				list.add(dto);
			}
			return list;
						
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		return null;
	}
	public void stuInfoCourseDel(VwstucouDTO coudto, String select) {
		String sql = "delete tblstudent where studentinfoseq =? and courseseq=?";
		
		try {
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, coudto.getVstuinseq());
			pstat.setString(2, select);
			
			pstat.execute();
						
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		
		
	}
	
//-------------------------------------------------------

	
	
}//class
