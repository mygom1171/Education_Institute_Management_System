package admin.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import dto.VwCourseDTO;
import dto.VwLecturerDTO;
import dto.VwSubjectDTO;
import dto.VwSubjectTypeDTO;
import util.DBUtil;

public class AdLecturerInfoDAO {

	private Connection conn;
	private Statement stat;
	private PreparedStatement pstat;
	
//-----------------------------------------------------	

	public AdLecturerInfoDAO() {
		
		try {
			DBUtil util = new DBUtil();
			this.conn = util.connect();
			this.stat = conn.createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("DAO생성자에서 오류");
		}
		
	}//method : AdLecturerInfoDAO
	
//-----------------------------------------------------	

	public boolean isConnected() {
		
		try {
			return !this.conn.isClosed();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return false;
		
	}
	
//-----------------------------------------------------
	
	public void close() {
		
		try {
			this.conn.close();
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
	}//Method : close
	
//===============================================================================================================================	
	
	//교사정보추가
	public int AdLecturerInfoadd(String name, String ssn, String tel ) {
		//1. stat or pstat : 매개변수 유무
		String sql = "insert into tblLecturer (seq, name, registrationnum, phonenum, state) values (lecturerSeq.nextval, ?, ?, ?, default)";
		
		try {
			
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, name);
			pstat.setString(2, ssn);
			pstat.setString(3, tel);
			
			return pstat.executeUpdate();			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}//AdLecturerInfoadd(VwLecturerDTO dto)
		
		
		
		return 0;
	}
	
//===============================================================================================================================
	
	//교사정보추가-강의가능과목추가
	public void AdLeAvlbadd(String sbseq) {

		String sql = "insert into tblAvlb (seq, lecturerseq, subjecttypeseq) values (tblAvlbSeq.nextval,  (SELECT MAX(seq) FROM tblLecturer), ?)";
				
			try {
					
				pstat = conn.prepareStatement(sql);
				pstat.setString(1, sbseq);

				pstat.executeUpdate();			
				
			} catch (SQLException e) {
				e.printStackTrace();
			}		
			
		}
		
//===============================================================================================================================

	//교사추가시 
	public ArrayList<VwLecturerDTO> avlbnamelist() {
		try {
			String sql = "select distinct vsubjectSeq, vsubjectNam from tblavlb order by vsubjectSeq";
			ResultSet rs = stat.executeQuery(sql);
			
			ArrayList<VwLecturerDTO> avlbnamelist = new ArrayList<VwLecturerDTO>();
			
			while(rs.next()) {
				//레코드 1개 -> DTO 1개
				VwLecturerDTO dto = new VwLecturerDTO();
				
				dto. setVsubjectSeq(rs.getString("vsubjectSeq")); //컬럼값 -> DTO멤버변수
				dto.setVsubjectName(rs.getString("vsubjectName"));
				
				avlbnamelist.add(dto);
				
			}//while
		
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return null;
	}//avlbnamelist()
	
//===============================================================================================================================
	
	//교사목록
	public ArrayList<VwLecturerDTO> lecturerinfolist() {
		try {
			
			String sql = "select distinct vlecturerSeq, vlecturerName, vlecturerRegistrationNum, vlecturerPhoneNum from vwLecturer order by vlecturerSeq";
			
			ResultSet rs = stat.executeQuery(sql);
			
			
			ArrayList<VwLecturerDTO> lecturerinfolist = new ArrayList<VwLecturerDTO>();
			
			//rs  ->  (복사) -> list
			while(rs.next()) {
				//레코드 1개 -> DTO 1개
				VwLecturerDTO dto = new VwLecturerDTO();
				
				dto.setVlecturerSeq(rs.getString("vlecturerSeq")); //컬럼값 -> DTO멤버변수
				dto.setVlecturerName(rs.getString("vlecturerName"));
				dto.setVlecturerRegistrationNum(rs.getString("vlecturerRegistrationNum"));
				dto.setVlecturerPhoneNum(rs.getString("vlecturerPhoneNum"));
		
				
				
				lecturerinfolist.add(dto);
			}//while
			
			return lecturerinfolist;
			
		} catch (Exception e) {
			System.out.println(e.toString());
			
			
		}
		
		return null;
	}
	
//===============================================================================================================================
	
	//입력받은 교사번호를 가져와 상세정보 출력
	public ArrayList<VwLecturerDTO> detailLecturerInfo(String selectnum) {

		try {
			
			String sql = String.format("select distinct vlecturerSeq, vlecturerName, vlecturerRegistrationNum, vlecturerPhoneNum from vwLecturer where vlecturerSeq = %s order by vlecturerSeq", selectnum);
			//         String sql = String.format("SELECT * FROM tblCourse WHERE seq = %s", n);
			
			
			ResultSet rs = stat.executeQuery(sql);

			ArrayList<VwLecturerDTO> lecturerinfolist = new ArrayList<VwLecturerDTO>();

			while(rs.next()) {
				
				VwLecturerDTO dto = new VwLecturerDTO();
				
				dto.setVlecturerSeq(rs.getString("vlecturerSeq")); 
				dto.setVlecturerName(rs.getString("vlecturerName"));
				dto.setVlecturerRegistrationNum(rs.getString("vlecturerRegistrationNum"));
				dto.setVlecturerPhoneNum(rs.getString("vlecturerPhoneNum"));

				lecturerinfolist.add(dto);
			}//while
			
			return lecturerinfolist;
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		return null;
	}
	
//===============================================================================================================================

	//교사 상세정보, (가능과목명)	
	public ArrayList<VwLecturerDTO> detailLeInfo(String selectnum) {
		try {
			
			String sql = String.format("select vsubjectName from vwLecturer where vsubjectSeq = %s order by vlecturerSeq", selectnum);
			ResultSet rs = stat.executeQuery(sql);

			ArrayList<VwLecturerDTO> detaillecturerinfo = new ArrayList<VwLecturerDTO>();
			
			while(rs.next()) {
				
				VwLecturerDTO dto = new VwLecturerDTO();
				
				dto.setVsubjectName(rs.getString("vsubjectName"));

				detaillecturerinfo.add(dto);
			}//while
			
			return detaillecturerinfo;
			
		} catch (Exception e) {
			System.out.println(e.toString());

		}
		return null;
	
	
	}//detailLeInfo(String selectnum)

//===============================================================================================================================
	
	//교사이름수정
	public int editLecturerName(String selectnum,  VwLecturerDTO dto) {

		try {
			
			String sql = String.format("update tblLecturer set name = ? where seq = %s", selectnum);
			
				pstat = conn.prepareStatement(sql);
				pstat.setString(1, dto.getVlecturerName());
				
			
			return pstat.executeUpdate();
			
			
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		
		
		return 0;
	};
	
//===============================================================================================================================

	//교사주민번호수정
	public int editLecturerssn(String selectnum,  VwLecturerDTO dto) {

		try {
			
			String sql = String.format("update tblLecturer set registrationNum = ? where seq = %s", selectnum);
			
				pstat = conn.prepareStatement(sql);
				pstat.setString(1, dto.getVlecturerRegistrationNum());

			return pstat.executeUpdate();

		} catch (Exception e) {
			System.out.println(e.toString());
		}

		return 0;
	}

//===============================================================================================================================
	
	//교사전화번호수정
	public int editLecturerPhoneNum(String selectnum, VwLecturerDTO dto) {
		
		try {
				
				String sql = String.format("update tblLecturer set phonenum = ? where seq = %s", selectnum);
				
					pstat = conn.prepareStatement(sql);
					pstat.setString(1, dto.getVlecturerPhoneNum());

				return pstat.executeUpdate();

			} catch (Exception e) {
				System.out.println(e.toString());
			}

		return 0;
	};
	
//===============================================================================================================================
	
	//강의가능과목수정
	public int editLecturerAvlb(String selectnum, String typeSeq2, String beforeSeq ) {
		
		try {
				
				String sql = "update tblavlb set SubjectTypeSeq = ? where lecturerSeq = ? and SubjectTypeSeq = ? ";
				
					pstat = conn.prepareStatement(sql);
					pstat.setString(1, typeSeq2);
					pstat.setString(2, selectnum);
					pstat.setString(3, beforeSeq);
					
				return pstat.executeUpdate();

			} catch (Exception e) {
				System.out.println(e.toString());
			}

		return 0;
	}

//===============================================================================================================================
	
	//전체 과목 목록
	public ArrayList<VwSubjectTypeDTO> subjectAllList() {
		try {
			
			String sql = "select distinct vTypeSeq, vTypeName from  VwSubjectType order by vTypeSeq";
			
			ResultSet rs = stat.executeQuery(sql);
			
			ArrayList<VwSubjectTypeDTO> list = new ArrayList<VwSubjectTypeDTO>();
			
			while(rs.next()) {
				
				VwSubjectTypeDTO dto = new VwSubjectTypeDTO();
				
				dto.setvTypeSeq(rs.getString("vTypeSeq")); 
				dto.setvTypeName(rs.getString("vTypeName"));

				list.add(dto);
			}
			
			return list;
			
		} catch (Exception e) {
			System.out.println(e.toString());
			
		}
		return null;
		
	}
	
//===============================================================================================================================
	
	//선생님 번호에 따른 강의가능 과목 목록
	public ArrayList<VwSubjectTypeDTO> subjectList(String selectnum) {
		try {
			
			String sql = String.format("select vTypeSeq, vTypeName, vlecturerseq from vwsubjectType where vlecturerseq = %s order by vTypeSeq", selectnum);
			ResultSet rs = stat.executeQuery(sql);

			ArrayList<VwSubjectTypeDTO> detaillecturerinfo = new ArrayList<VwSubjectTypeDTO>();
			
			while(rs.next()) {
				
				VwSubjectTypeDTO dto = new VwSubjectTypeDTO();
				
				dto.setvTypeSeq(rs.getString("vTypeSeq"));
				dto.setvTypeName(rs.getString("vTypeName"));

				detaillecturerinfo.add(dto);
				
			}//while
			
			return detaillecturerinfo;
			
		} catch (Exception e) {
			System.out.println(e.toString());

		}
		return null;
	
	
	}//detailLeInfo(String selectnum)

//===============================================================================================================================
	
	public ArrayList<VwCourseDTO> coursecheck(String selectnum) {
		try {
		
		String sql = String.format("SELECT VcourseName,  VcourseStartDate, VcourseEndDate, Vclassroom FROM VwCourse WHERE vlecturerSeq = %s AND VcourseStartDate > sysdate AND VcourseEndDate > sysdate", selectnum);
		ResultSet rs = stat.executeQuery(sql);

		ArrayList<VwCourseDTO> detailcoursecheck = new ArrayList<VwCourseDTO>();
		
			while(rs.next()) {
				
				VwCourseDTO dto = new VwCourseDTO();
				
				dto.setVcourseName(rs.getString("VcourseName"));
				dto.setVcourseStartDate(rs.getString("VcourseStartDate"));
				dto.setVcourseEndDate(rs.getString("VcourseEndDate"));
				dto.setVclassroom(rs.getString("Vclassroom"));

	
				detailcoursecheck.add(dto);
				
			}//while
			
		return detailcoursecheck;
		
		} catch (Exception e) {
			System.out.println(e.toString());

		}
		return null;
	}	
	
//===============================================================================================================================
	
	public ArrayList<VwSubjectDTO> subjectcheck(String selectnum) {
		try {
		
		String sql = String.format("SELECT vsubjectName,  vsubjectStartDate, vsubjectEndDate, vTextbook FROM VwSubject  WHERE vlecturerSeq = %s", selectnum);
		ResultSet rs = stat.executeQuery(sql);

		ArrayList<VwSubjectDTO> detailsubjectcheck = new ArrayList<VwSubjectDTO>();
		
			while(rs.next()) {
				
				VwSubjectDTO dto = new VwSubjectDTO();
				
				dto.setVsubjectName(rs.getString("VsubjectName"));
				dto.setVsubjectStartDate(rs.getString("vsubjectStartDate"));
				dto.setVsubjectEndDate(rs.getString("vsubjectEndDate"));
				dto.setvTextbook(rs.getString("vTextbook"));

	
				detailsubjectcheck.add(dto);
				
			}//while
			
		return detailsubjectcheck;
		
		} catch (Exception e) {
			System.out.println(e.toString());

		}
		
		return null;
	}	
	
}//class : AdLecturerInfoDAO


