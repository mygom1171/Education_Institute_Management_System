package admin.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import dto.ClassRoomDTO;
import dto.CourseNameDTO;
import dto.PublisherDTO;
import dto.SubjectNameDTO;
import dto.SubjectTypeDTO;
import dto.TextBookDTO;
import dto.VwTextbookInfoDTO;
import util.DBUtil;

public class AdministratorBasicInfoDAO {

	private Connection conn;
	private Statement stat;
	private PreparedStatement pstat;
		
		public AdministratorBasicInfoDAO() {
			
			try {
				DBUtil util = new DBUtil();
				this.conn = util.connect();
				this.stat = conn.createStatement();
				
			} catch (SQLException e) {
				e.printStackTrace();
				System.out.println("DAO생성자에서 오류");
			}
			
		}//method : AdministratorBasicInfoDAO
		
		public boolean isConnected() {
			
			try {
				return !this.conn.isClosed();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
			return false;
		}
		
		public void close() {
			
			try {
				this.conn.close();
			} catch (Exception e) {
				System.out.println(e.toString());
			}
			
		}//Method : close

	//과정 목록 
	//=============================================================================================
		
		public ArrayList<CourseNameDTO> basicCourseList() {
			
			try {
				
				String sql = "select * from tblCourseName where state = 1";
				
				ResultSet rs = stat.executeQuery(sql);
				
				ArrayList<CourseNameDTO> list = new ArrayList<CourseNameDTO>();
				
				while (rs.next()) {
					//레코드 1개 -> DTO 1개
					CourseNameDTO dto = new CourseNameDTO();
					
					dto.setSeq(rs.getString("seq")); //컬럼값 -> DTO 멤버변수
					dto.setName(rs.getString("name"));
					dto.setState(rs.getString("state"));
				
					list.add(dto);
				}
				
				return list;
				
				
			} catch (Exception e) {
				System.out.println(e.toString());
			} 
			
			return null;
		}
	//과정명 수정
	//=================================================================================================================		
			
		public String selectCourseNameEdit(String courseNameSeq) {
			
			try {
				
				String sql = String.format("SELECT * FROM tblCourseName WHERE seq = %s", courseNameSeq);
				ResultSet rs = stat.executeQuery(sql);
				
				while (rs.next()) {
					String courseName = rs.getString("name");
					return courseName;
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
			return null;
			
		}//method : selectCourseName
		

	//과정명 추가
	//============================================================================================================	
		public int courseAdd(CourseNameDTO dto) {
			
			String sql = "insert into tblCourseName (seq, name, state) values"
					+ "(courseNameSeq.nextval, ?, default)";
		
		try {
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, dto.getName());
			pstat.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return 0;
		
		}
	
	//과정명 수정
	//============================================================================================================		
		
		public int courseEdit(CourseNameDTO dto) {
			
			try {
				
				String sql = "UPDATE tblCourseName SET name = ?, state = default WHERE seq = ?";
				
				pstat = conn.prepareStatement(sql);
				pstat.setString(1, dto.getName());
				pstat.setString(2, dto.getSeq());
				
				return pstat.executeUpdate();
			
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
			return 0;
			
		}
		
		
	//과정명 삭제
	//=============================================================================================			
		public int courseDel(CourseNameDTO dto) {
			
			try {
				
				String sql = "UPDATE tblCourseName SET state = 0 where seq = ?";
				
				pstat = conn.prepareStatement(sql);
				pstat.setString(1, dto.getSeq());
				
				return pstat.executeUpdate();
						
			} catch (Exception e) {
				System.out.println(e.toString());
			}
			
			return 0;
			
		}
		
	//과목명 리스트
	//=============================================================================================	
		
		public ArrayList<SubjectNameDTO> basicSubjectList() {
			
			try {
				
				String sql = "SELECT * FROM tblSubjectName WHERE state = 1";
				
				ResultSet rs = stat.executeQuery(sql);
				
				ArrayList<SubjectNameDTO> list = new ArrayList<SubjectNameDTO>();
				
				while(rs.next()) {
					
					SubjectNameDTO dto = new SubjectNameDTO();
					
					dto.setSeq(rs.getString("seq"));
					dto.setName(rs.getString("name"));
					dto.setSubjectTypeSeq(rs.getString("subjecttypeseq"));
					dto.setState(rs.getString("state"));
					
				list.add(dto);
				
				}
				return list;
				
				
			} catch (Exception e) {
				System.out.println(e.toString());
			}
			
			return null;
			
		}
	//과목 유형 리스트 	
	//=============================================================================================	
		
		public ArrayList<SubjectTypeDTO> basicSubjectTypeList() {
			
			try {
				
				String sql = "SELECT * FROM tblSubjectType";
				
				ResultSet rs = stat.executeQuery(sql);
				
				ArrayList<SubjectTypeDTO> list = new ArrayList<SubjectTypeDTO>();
				
				while(rs.next()) {
					
					SubjectTypeDTO dto = new SubjectTypeDTO();
					
					dto.setSeq(rs.getString("seq"));
					dto.setName(rs.getString("name"));
					dto.setState(rs.getString("state"));
					
				list.add(dto);
				
				}
				return list;
				
				
			} catch (Exception e) {
				System.out.println(e.toString());
			}
			
			return null;
		
		}
	//과목명 선택 	
	//=============================================================================================
		
		public String selectSubjectNameEdit (String basicOldSubjectNameSeq) {
			
			try {
				
				String sql = String.format("SELECT * FROM tblSubjectName WHERE seq = %s", basicOldSubjectNameSeq);
				ResultSet rs = stat.executeQuery(sql);
				
				while(rs.next()) {
					
					String subjectName = rs.getString("name");
					return subjectName;
				}
				
			} catch (Exception e) {
				System.out.println(e.toString());
			}
			return null;
			
		}
	//과목명 추가	
	//=============================================================================================
		
		public int subjectAdd(SubjectNameDTO dto) {
			
			String sql = "insert into tblSubjectName (seq, name, subjecttypeseq, state) values"
					+ "(subjectNameSeq.nextval, ?, ?, default)";
		
		try {
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, dto.getName());
			pstat.setString(2, dto.getSubjectTypeSeq());
			pstat.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return 0;
		
		}
	//과목명 수정	
	//=============================================================================================	
		
		public int subjectEdit(SubjectNameDTO dto) {
			
			try {
				
				String sql = "UPDATE tblSubjectName SET name = ?, state = default WHERE seq = ?";
				
				pstat = conn.prepareStatement(sql);
				pstat.setString(1, dto.getName());
				pstat.setString(2, dto.getSeq());
				
				return pstat.executeUpdate();
			
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
			return 0;
			
		}
	//과목명 삭제	
	//=============================================================================================
		
		public int subjectDel(SubjectNameDTO dto) {
			
			try {
				
				String sql = "UPDATE tblSubjectName SET state = 0 where seq = ?";
				
				pstat = conn.prepareStatement(sql);
				pstat.setString(1, dto.getSeq());
				
				return pstat.executeUpdate();
						
			} catch (Exception e) {
				System.out.println(e.toString());
			}
			
			return 0;
			
		}
		
	//강의실 리스트	
	//=============================================================================================
		
		public ArrayList<ClassRoomDTO> basicClassRoomList() {
			
			try {
				
				String sql = "SELECT * FROM tblClassroom where state = 1";
				
				ResultSet rs = stat.executeQuery(sql);
				
				ArrayList<ClassRoomDTO> list = new ArrayList<ClassRoomDTO>();
				
				while (rs.next()) {
					//레코드 1개 -> DTO 1개
					ClassRoomDTO dto = new ClassRoomDTO();
					
					dto.setSeq(rs.getString("seq")); //컬럼값 -> DTO 멤버변수
					dto.setName(rs.getString("name"));
					dto.setNum(rs.getString("num"));
					dto.setState(rs.getString("state"));
				
					list.add(dto);
				}
				
				return list;
				
				
			} catch (Exception e) {
				System.out.println(e.toString());
			} 
			
			return null;
		}
		
	//강의실명 선택
	//=============================================================================================	
		
		public String selectClassroomNameEdit (String editClassroomNum) {
			
			try {
				
				String sql = String.format("SELECT * FROM tblClassroom WHERE seq = %s", editClassroomNum);
	
				ResultSet rs = stat.executeQuery(sql);
				
				while(rs.next()) {
					String ClassroomName = rs.getString("name");
					return ClassroomName;
				}
				
			} catch (Exception e) {
				System.out.println(e.toString());
			}
			
			return null;
		}
	//강의실정원 선택 	
	//=============================================================================================	
		
		public String selectClassroomNumEdit (String editClassroomNum) {
			
			try {
				
				String sql = String.format("SELECT * FROM tblClassroom WHERE seq = %s", editClassroomNum);
				
				ResultSet rs = stat.executeQuery(sql);
				
				while(rs.next()) {
					String ClassroomNum = rs.getString("num");
					
					return ClassroomNum;
				}
				
			} catch (Exception e) {
				System.out.println(e.toString());
			}
			
			return null;
			
		}
		
	//강의실명 수정	
	//=============================================================================================	
		
		public int classroomNameEdit (ClassRoomDTO dto) {
			
			try {
				
				String sql = "UPDATE tblClassroom SET name = ?, state = default WHERE seq = ?";
				
				pstat = conn.prepareStatement(sql);
				pstat.setString(1, dto.getName());
				pstat.setString(2, dto.getSeq());
				
				return pstat.executeUpdate();
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
			return 0;
		}
		
	//강의실 정원 수정
	//=============================================================================================	
		
		public int classroomNumEdit (ClassRoomDTO dto) {
			
			try {
				
				String sql = "UPDATE tblClassroom SET state = default, num = ? WHERE seq = ?";
				
				pstat = conn.prepareStatement(sql);
				pstat.setString(1, dto.getNum());
				pstat.setString(2, dto.getSeq());
				
				return pstat.executeUpdate();
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
			return 0;
		}
		
	//교재,출판사 리스트 
	//=============================================================================================	
		
		public ArrayList<VwTextbookInfoDTO> basicTextbookList() {
			
			try {
				
				String sql = "SELECT * FROM vwTextbookInfo";
				
				ResultSet rs = stat.executeQuery(sql);
				
				ArrayList<VwTextbookInfoDTO> list = new ArrayList<VwTextbookInfoDTO>();
				
				while (rs.next()) {
					//레코드 1개 -> DTO 1개
					VwTextbookInfoDTO dto = new VwTextbookInfoDTO();
					
					dto.setvTextbookSeq(rs.getString("vTextbookSeq")); 
					dto.setvTextbookName(rs.getString("vTextbookName"));
					dto.setvPublisher(rs.getString("vPublisher"));
					dto.setvTextbookState(rs.getString("vTextbookState"));
					
				
					list.add(dto);
				}
				
				return list;
				
				
			} catch (Exception e) {
				System.out.println(e.toString());
			} 
			
			return null;
		}
		
	//교재 명 추가
	//=============================================================================================	
		
		public int textbookAdd(TextBookDTO DTO) {
			
			String sql = "INSERT INTO tblTextBook (seq, publisherseq, name, state) values"
					+ "(tblTextbookSeq.NEXTVAL, ?, ?, default)";
		
		try {
			pstat = conn.prepareStatement(sql);
			pstat.setString(1, DTO.getPublisherSeq());
			pstat.setString(2, DTO.getName());
			
			return pstat.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return 0;
		
		}
		
	//출판사 리스트
	//=============================================================================================	
		
		public ArrayList<PublisherDTO> publisherList() {
			
			try {
				
				String sql = "SELECT * FROM tblPublisher where state = 1";
				
				ResultSet rs = stat.executeQuery(sql);
				
				ArrayList<PublisherDTO> list = new ArrayList<PublisherDTO>();
				
				while (rs.next()) {
					
					PublisherDTO dto = new PublisherDTO();
					
					dto.setSeq(rs.getString("seq")); //컬럼값 -> DTO 멤버변수
					dto.setName(rs.getString("name"));
					dto.setState(rs.getString("state"));
				
					list.add(dto);
				}
				
				return list;
				
				
			} catch (Exception e) {
				System.out.println(e.toString());
			} 
			
			return null;
		}
		
	//교재명 리스트	
	//=============================================================================================	
		
		public ArrayList<TextBookDTO> textbookList() {
			
			try {
				
				String sql = "SELECT * FROM tblTextbook where state = 1";
				
				ResultSet rs = stat.executeQuery(sql);
				
				ArrayList<TextBookDTO> list = new ArrayList<TextBookDTO>();
				
				while (rs.next()) {
					
					TextBookDTO dto = new TextBookDTO();
					
					dto.setSeq(rs.getString("seq")); 
					dto.setPublisherSeq(rs.getString("publisherseq"));
					dto.setName(rs.getString("name"));
					dto.setState(rs.getString("state"));
				
					list.add(dto);
				}
				
				return list;
				
				
			} catch (Exception e) {
				System.out.println(e.toString());
			} 
			
			return null;
		}
	
	//교재명 선택
	//============================================================================================================		

		public String selectTextbookNameEdit (String basicOldTextbookNameSeq) {
			
			try {
				
				String sql = String.format("SELECT * FROM tblTextbook WHERE seq = %s", basicOldTextbookNameSeq);
				ResultSet rs = stat.executeQuery(sql);
				
				while(rs.next()) {
					
					String textbookName = rs.getString("name");
					return textbookName;
				}
				
			} catch (Exception e) {
				System.out.println(e.toString());
			}
			return null;
			
		}
	
	//교재명 수정
	//============================================================================================================	
		
		public int textbookNameEdit(TextBookDTO dto) {
			
			try {
				
				String sql = "UPDATE tblTextbook SET name = ?, state = default WHERE seq = ?";
				
				pstat = conn.prepareStatement(sql);
				pstat.setString(1, dto.getName());
				pstat.setString(2, dto.getSeq());
				
				return pstat.executeUpdate();
			
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
			return 0;
			
		}
		
	//출판사명 선택
	//============================================================================================================	
		
		public String selectPublisherNameEdit (String basicOldPublisherNameSeq) {
			
			try {
				
				String sql = String.format("SELECT * FROM tblPublisher WHERE seq = %s", basicOldPublisherNameSeq);
				ResultSet rs = stat.executeQuery(sql);
				
				while(rs.next()) {
					
					String publisherName = rs.getString("name");
					return publisherName;
				}
				
			} catch (Exception e) {
				System.out.println(e.toString());
			}
			return null;
			
		}
		
	//출판사명 수정
	//============================================================================================================	
		
		public int publisherNameEdit(PublisherDTO dto) {
			
			try {
				
				String sql = "UPDATE tblPublisher SET name = ?, state = default WHERE seq = ?";
				
				pstat = conn.prepareStatement(sql);
				pstat.setString(1, dto.getName());
				pstat.setString(2, dto.getSeq());
				
				return pstat.executeUpdate();
			
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
			return 0;
			
		}
	// 출판사명 선택	
	//=============================================================================================	
		
		public String selectTextbookEdit(String DelTextbookSeq) {
			
			try {
				
				String sql = String.format("SELECT * FROM tblTextbook WHERE seq = %s", DelTextbookSeq);
				ResultSet rs = stat.executeQuery(sql);
				
				while (rs.next()) {
					String textbookName = rs.getString("name");
					return textbookName;
				}
				
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
			return null;
			
		}
		
	//교재명 삭제
	//============================================================================================================	
		
		public int textbookDel(TextBookDTO dto) {
			
			try {
				
				String sql = "UPDATE tblTextbook SET state = 0 where seq = ?";
				
				pstat = conn.prepareStatement(sql);
				pstat.setString(1, dto.getSeq());
				
				return pstat.executeUpdate();
						
			} catch (Exception e) {
				System.out.println(e.toString());
			}
			
			return 0;
			
		}
}
